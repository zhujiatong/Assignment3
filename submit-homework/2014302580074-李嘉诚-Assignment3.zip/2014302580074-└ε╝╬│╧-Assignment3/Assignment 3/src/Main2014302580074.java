/**
 _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                        ���汣��       ����BUG
*@author Vintony.Lee
*@version 1.0
*note��
*1���������ǻ���һ������
*2�ǵö࿴��
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main2014302580074
{
	public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException, InterruptedException
	{
		long singleStartTime=System.currentTimeMillis(); 		//�洢���߳̿�ʼʱ��
		TeacherImformation2014302580074 single=new TeacherImformation2014302580074();
		single.FindTeacherList();
		for(int i=0;i<TeacherImformation2014302580074.teacherNumber;i++)
		{
			String[] temp = new String[4];
			temp=single.Process(single.getTeacherList(i));
			String sql;
			sqlConnect2014302580074 database=new sqlConnect2014302580074();	
			Connection conn=database.getConnection();
			PreparedStatement ps=null;
			sql="insert into teacher(name,phone,email,introduction) values('"+temp[0]+"','"+temp[1]+"','"+temp[2]+"','"+temp[3]+"');";				
			ps=conn.prepareStatement(sql);
			ps.executeUpdate(sql);			
			ps.close();
			conn.close();
		}
		long singleEndTime=System.currentTimeMillis();
		System.out.println("���߳�ʱ�䣺"+(singleEndTime-singleStartTime)+"ms");
		
		Long mutiStartTime=System.currentTimeMillis(); //��ȡ���߳̿�ʼʱ��
		final TeacherImformation2014302580074 muti=new TeacherImformation2014302580074();
		muti.FindTeacherList();
		final Buffer2014302580074 tempBuffer=new Buffer2014302580074();
		
		Thread[] getHTMLThread=new Thread[TeacherImformation2014302580074.teacherNumber];
		for( int i=0;i<TeacherImformation2014302580074.teacherNumber;i++)
		{
			final int number=i;
			getHTMLThread[i]=new Thread(
			new Runnable()
			{
				public void run()
				{			
					try
					{
						tempBuffer.setFile(muti.getHtml(muti.getTeacherList(number), number));
						
					} catch (InterruptedException e)
					{
						e.printStackTrace();
					}
				}
			}
			);
		}
		
		Thread parseHTMLThread=new Thread(
				new Runnable() 
				{
					public void run()
					{
						for(int i=0;i<TeacherImformation2014302580074.teacherNumber;i++)
						{
							try
							{
								while(tempBuffer.getFile(i)==null)
								{
									Thread.sleep(10);
								}//�����������file��δд��buffer��			
								muti.Process(tempBuffer.getFile(i));
						
							} catch (IOException e)
							{
								e.printStackTrace();
							} catch (InterruptedException e) 
							{
								e.printStackTrace();
							}
						}
					}
				});
		
		for(int i=0;i<TeacherImformation2014302580074.teacherNumber;i++)
		{
			getHTMLThread[i].start();
		}
		parseHTMLThread.start();
		for(int i=0;i<TeacherImformation2014302580074.teacherNumber;i++)
		{
			getHTMLThread[i].join();
		}
		parseHTMLThread.join();
		long mutiEndTime=System.currentTimeMillis();
		System.out.println("���߳�ʱ�䣺"+(mutiEndTime-mutiStartTime)+"ms");		
		System.out.println("Success��");
	}
}

