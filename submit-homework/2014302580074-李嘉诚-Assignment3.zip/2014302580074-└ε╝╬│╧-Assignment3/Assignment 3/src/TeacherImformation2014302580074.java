import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class TeacherImformation2014302580074
{

	private String url;
	private String index;
	private File input;
	private String[] teacherList;
	private String prefixURL;
	public final static int teacherNumber=20;
	public static int getTeacherNumber(){return teacherNumber;};
	public TeacherImformation2014302580074()
	{
		index="List.html";
		input=new File(index);
		url="http://staff.whu.edu.cn/?key=&college=&cid=0&showhomepage=0&lang=cn&p=1&title=0";				
		prefixURL="http://staff.whu.edu.cn/";
	}
	public String getTeacherList(int count)
	{
		return teacherList[count];
	}
	//��ý�ʦ�б��и�����ʦ�ĸ�����ҳ��url��ַ
	
	public void FindTeacherList() throws IOException
	{	HttpRequest temp=new HttpRequest(url,"GET");
		temp.receive(input);
		teacherList=new String[teacherNumber];
		Document document=Jsoup.parse(input,"UTF-8");
		Elements temp1=document.getElementsByTag("p");
		int count=0;
		while(count!=teacherNumber)
		{
		Element temp2=temp1.get(count);
		Elements urls=temp2.select("a");
		String url=urls.attr("href");
		teacherList[count]=prefixURL+url;
		count++;
		}
	}
	
	public File getHtml(String url,int count){	
			String fileName=count+"Teacher.html";
			File teacherHTML=new File(fileName);
			HttpRequest httpRequest=new HttpRequest(url,"GET");
			httpRequest.receive(teacherHTML);
			return teacherHTML;
	}
	
	
	
	
	public String[] Process(String url)throws IOException        //��urlΪ�����process
	{
		Document doc=Jsoup.connect(url).get();
		String[] inf = new String[4];
		inf[3] = "";
		String mailRegex = "\\w[-\\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\\.)+[A-Za-z]{2,14}"; 						//����������������ʽ
		String telRegex = "(13\\d|14[57]|15[^4,\\D]|17[678]|18\\d)\\d{8}|170[059]\\d{7}";                       //����绰������������ʽ                                         
		Elements imformation1 = doc.select("div.col-md-10");        
		Elements imformation2 = doc.select("div.szll_wz");                                      
		for(Element e:imformation2)                                 
		{
			Elements ed = e.select("div.szll_wz_bt");               
			Elements ep = e.select("p");                           
			for(Element el:ed)                                     
			{
				if(el.text() != null){
					inf[3] += el.text()+":";
				}
			}
			for(Element el:ep)                                     
			{
				if(el.text() != null){
					inf[3] += el.text();
				}
			}
			inf[3] += " ";
		}
		String details = imformation1.select("p").text();           
		String st = details.replaceAll(" *, *", "");               
		inf[0] = imformation1.select("h3").text();             //��ȡ����
		String[] servrals = st.split(" ");                       
		for(String s:servrals)                                    
		{
			if(s.matches(telRegex))                                //��ȡ�绰����
			{
				inf[1] = s;
			}else if (s.matches(mailRegex)) {                      //��ȡ�����ַ
				inf[2] = s;
			}
		}
		return inf;
	}
	
	
	public String[] Process(File file)throws IOException      //���ļ������process
	{
		Document doc=Jsoup.parse(file, "UTF-8");
		String[] inf = new String[4];
		inf[3] = "";
		String mailRegex = "\\w[-\\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\\.)+[A-Za-z]{2,14}"; 						//����������������ʽ
		String telRegex = "(13\\d|14[57]|15[^4,\\D]|17[678]|18\\d)\\d{8}|170[059]\\d{7}";                       //����绰������������ʽ                                         
		Elements imformation1 = doc.select("div.col-md-10");       
		Elements imformation2 = doc.select("div.szll_wz");                              
		for(Element e:imformation2)                                
		{
			Elements ed = e.select("div.szll_wz_bt");               
			Elements ep = e.select("p");                          
			for(Element el:ed)                                      
			{
				if(el.text() != null){
					inf[3] += el.text()+":";
				}
			}
			for(Element el:ep)                                     
			{
				if(el.text() != null){
					inf[3] += el.text();
				}
			}
			inf[3] += " ";
		}
		if(inf[3].length()>15){
			inf[3]="̫����";
		}
		String details = imformation1.select("p").text();          
		String st = details.replaceAll(" *, *", "");               
		inf[0] = imformation1.select("h3").text();             //��ȡ����
		String[] servrals = st.split(" ");                       
		for(String s:servrals)                                   
		{
			if(s.matches(telRegex))                                //��ȡ�绰����
			{
				inf[1] = s;
			}else if (s.matches(mailRegex)) {                      //��ȡ�����ַ
				inf[2] = s;
			}
		}
		return inf;
	}
}


