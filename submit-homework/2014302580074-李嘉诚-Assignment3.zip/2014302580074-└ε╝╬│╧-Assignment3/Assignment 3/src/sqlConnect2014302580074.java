import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class sqlConnect2014302580074 {
	public String url ;
	public String username; 
	public String password ; 
	public sqlConnect2014302580074()
	{
		url ="jdbc:mysql://127.0.0.1:3306/new_schema";//localhost
		username = "root"; 
		password = "5078101823"; 
	}
	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,username,password);
			System.out.println("���������ɹ�");
	        return conn;
	}catch(ClassNotFoundException e)
	{
		System.out.println("�Ҳ������������� ����������ʧ�ܣ�");   
	    e.printStackTrace() ; 
	    return null;
	}catch(SQLException e)
	{
		System.out.println("MySQL��������");
        e.printStackTrace();
        return null;
	}
	}
}
