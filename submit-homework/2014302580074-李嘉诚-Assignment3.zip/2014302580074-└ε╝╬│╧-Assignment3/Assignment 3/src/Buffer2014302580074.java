import java.io.File;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Buffer2014302580074
{
	private Lock lock;
	private File[] file;
	private int bufferNumber;
	
	public Buffer2014302580074()
	{
		bufferNumber=TeacherImformation2014302580074.teacherNumber;
		file=new File[bufferNumber];
		lock=new ReentrantLock();
	}
	
	
	public void setFile(File file) throws InterruptedException
	{
		lock.lock();
		try
		{
			for(int i=0;i<bufferNumber;i++)
			{
				if(this.file[i]==null)
				{
					this.file[i]=file;
					break;
				}
			}
		}finally
		{
			lock.unlock();
			//condition.signalAll();
		}
		
	}
	
	public File getFile(int number) throws InterruptedException
	{
		return file[number];
	
	}
}