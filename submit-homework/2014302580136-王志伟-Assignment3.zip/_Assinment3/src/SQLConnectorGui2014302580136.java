import javax.swing.*;
import java.awt.*;

/**
 * Created by inksmallfrog on 15-11-5.
 */
//主窗口
public class SQLConnectorGui2014302580136 extends JFrame{
    private JPanel panel_user;
    private JLabel label_user;
    private JTextField text_user;

    private JPanel panel_password;
    private JLabel label_password;
    private JPasswordField text_password;

    private JPanel panel_database;
    private JLabel label_database;
    private JTextField text_database;

    private JPanel panel_maxNumber;
    private JLabel label_maxNumber;
    private JTextField text_maxNumber;

    private JButton button_singleThread;
    private JButton button_multiThreads;

    public SQLConnectorGui2014302580136(){
        setSize(500, 500);
        setLocation(0, 0);
        setTitle("浙江大学教师信息爬取");
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //创建窗口各组件
        CreateCompositions();

        setVisible(true);
    }

    //初始化Mysql链接
    private boolean InitMysql(){
        MysqlConnector2014302580136.getInstance().setUser(text_user.getText());
        MysqlConnector2014302580136.getInstance().setPassword(new String(text_password.getPassword()));
        MysqlConnector2014302580136.getInstance().setDatabase(text_database.getText());
        return MysqlConnector2014302580136.getInstance().Connect();
    }

    private void CreateCompositions(){
        CreateUserPanel();
        CreatePasswordPanel();
        CreateDatabasePanel();
        CreateMaxPanel();
        CreateButtons();

        CreateListener();

        add(panel_user);
        add(panel_password);
        add(panel_database);
        add(panel_maxNumber);
        add(button_singleThread);
        add(button_multiThreads);
    }

    private void CreateUserPanel(){
        panel_user = new JPanel();
        panel_user.setLayout(new BoxLayout(panel_user, BoxLayout.X_AXIS));
        label_user = new JLabel("User:      ");
        text_user = new JTextField("root");
        panel_user.add(label_user);
        panel_user.add(text_user);
        panel_user.setBounds(137, 100, 243, 20);
    }

    private void CreatePasswordPanel(){
        panel_password = new JPanel();
        panel_password.setLayout(new BoxLayout(panel_password, BoxLayout.X_AXIS));
        label_password = new JLabel("Password:      ");
        text_password = new JPasswordField("3345*moxiaowa");
        panel_password.add(label_password);
        panel_password.add(text_password);
        panel_password.setBounds(100, 150, 280, 20);
    }

    private void CreateDatabasePanel(){
        panel_database = new JPanel();
        panel_database.setLayout(new BoxLayout(panel_database, BoxLayout.X_AXIS));
        label_database = new JLabel("Database:      ");
        text_database = new JTextField("teacher_test");
        panel_database.add(label_database);
        panel_database.add(text_database);
        panel_database.setBounds(100, 200, 280, 20);
    }

    private void CreateMaxPanel(){
        panel_maxNumber = new JPanel();
        panel_maxNumber.setLayout(new BoxLayout(panel_maxNumber, BoxLayout.X_AXIS));
        label_maxNumber = new JLabel("MaxNumber:      ");
        text_maxNumber = new JTextField("10");
        panel_maxNumber.add(label_maxNumber);
        panel_maxNumber.add(text_maxNumber);
        panel_maxNumber.setBounds(85, 250, 295, 20);
    }

    private void CreateButtons(){
        button_singleThread = new JButton("单线程运行");
        button_singleThread.setBounds(280, 300, 100, 20);
        button_multiThreads = new JButton("多线程运行");
        button_multiThreads.setBounds(280, 340, 100, 20);
    }

    //创建按钮监听事件
    private void CreateListener(){
        //单线程按钮
        button_singleThread.addActionListener(e -> {
            //尝试链接数据库
            if (!InitMysql()) {
                JOptionPane.showMessageDialog(null, "账号或密码错误");
                return;
            }
            //执行爬取过程
            PageCrawler2014302580136 crawler = new PageCrawler2014302580136(Integer.parseInt(text_maxNumber.getText()));
            crawler.runWithSingleThread();
            //显示爬取信息
            ShowRunningMessage(crawler);
        });
        //多线程按钮
        button_multiThreads.addActionListener(e -> {
            if (!InitMysql()) {
                JOptionPane.showMessageDialog(null, "账号或密码错误");
                return;
            }
            EventQueue.invokeLater(() -> {
                PageCrawler2014302580136 crawler = new PageCrawler2014302580136(Integer.parseInt(text_maxNumber.getText()));
                crawler.runWithMultiThreads();
                ShowRunningMessage(crawler);
            });
        });
    }

    //显示爬取信息
    private void ShowRunningMessage(PageCrawler2014302580136 crawler){
        String message = "运行时间: " + crawler.getRunTime() + "\n";
        message += "成功抓取: " + crawler.getSuccessRead() + "\n";
        message += "链接失败: " + crawler.getFailed_disconnect() + "\n";
        message += "信息不全: " + crawler.getFailed_noInfo() + "\n";
        message += "存入表数据库: " + text_database.getText() + " table: " + "2014302580136Teacher";
        JOptionPane.showMessageDialog(null, message);
    }
}
