import java.sql.*;

/**
 * Created by inksmallfrog on 15-11-5.
 */
//单例化Mysql连接类
public class MysqlConnector2014302580136 {
    private static MysqlConnector2014302580136 ourInstance = new MysqlConnector2014302580136();

    public static MysqlConnector2014302580136 getInstance() {
        return ourInstance;
    }

    private MysqlConnector2014302580136() {
        try {
            Class.forName(driver);
        }
        catch (ClassNotFoundException e){
            e.printStackTrace();
        }
    }

    String driver = "com.mysql.jdbc.Driver";            //连接驱动
    String baseUrl = "jdbc:mysql://localhost:3306/";    //本机地址和接口
    String talbe = "2014302580136ZJUTeachers";          //表格名
    String user;                                        //用户名
    String password;                                    //密码
    String database;                                    //数据库名
    Connection conn = null;                             //连接信息

    public void setDatabase(String _database){
        database = "teacher_test";
    }
    public void setUser(String _user){
        user = "root";
    }
    public void setPassword(String _password){
        password = "";
    }

    //尝试连接数据库
    public boolean Connect(){
        try {
            //尝试依据现有地址，用户和密码访问数据库
            conn = DriverManager.getConnection(baseUrl, user, password);
            if(conn == null){
                return false;
            }

            //检查数据库存在，并创建表
            Statement stm = conn.createStatement();
            stm.execute("CREATE DATABASE IF NOT EXISTS " + database + ";");
            stm.execute("use " + database + ";");

            stm.execute("DROP TABLE IF EXISTS " + talbe);
            stm.execute("CREATE TABLE " + talbe + "(" +
                    "姓名 VARCHAR(30)," +
                    "专业 VARCHAR(300)," +
                    "职称 VARCHAR(50)," +
                    "简介 TEXT(65535)," +
                    "研究方向 TEXT(65535)," +
                    "电话号码 VARCHAR(50)," +
                    "邮箱 VARCHAR(100)" +
                    ")");
        }
        catch (SQLException e){
            return false;
        }
        return true;
    }

    //插入数据
    public void Insert(TeacherInfo2014302580136 info){
        try {
            Statement stm = conn.createStatement();
            stm.execute("use " + database + ";");
            stm.execute("INSERT INTO " + talbe +
                    " (姓名, 专业, 职称, 简介, 研究方向, 电话号码, 邮箱) " +
                    "VALUES(\"" +
                    info.getName() + "\", \"" +
                    info.getMaster() + "\", \"" +
                    info.getLevel() + "\", \"" +
                    info.getBrief() + "\", \"" +
                    info.getTarget() + "\", \"" +
                    info.getPhone() + "\", \"" +
                    info.getEmail() + "\");");
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
}
