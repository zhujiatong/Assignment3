import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by inksmallfrog on 15-11-5.
 */
public class PageCrawler2014302580136 {
    //定义爬取线程
    class CrawlerThread extends Thread{
        public void run(){
            if(urls.isEmpty()){
                return;
            }
            String url;
            synchronized (urls) {
                url = urls.poll();
            }
            CrawTeacherInfo2014302580136(url);
        }
    }

    private String originUrl;                       //初始网址
    private String domain;                          //网站域名
    private int currentPage;                        //当前页
    private int maxPage;                            //最大页
    private int maxNumber;                          //最大爬取数
    private Integer successRead;                    //成功爬取数
    private Integer failed_noInfo;                  //信息不全数
    private Integer failed_disconnect;              //连接失败数
    private long startTime;                         //起始时间
    private long endTime;                           //结束时间
    private Queue<String> pages;                    //表格页面队列
    private ConcurrentLinkedQueue<String> urls;     //教师页面队列

    private Thread thread_pageReader;               //读取表格页面线程
    private Thread[] thread_inforeaders;            //读取教师页面线程

    public PageCrawler2014302580136(int _maxNumber){
        maxNumber = _maxNumber;
        urls = new ConcurrentLinkedQueue<>();
        pages = new PriorityQueue<>();
        InitCrawler();
    }

    //单线程运行
    public void runWithSingleThread(){
        InitCrawler();
        startTime = System.currentTimeMillis();
        GetTeacherUrls(pages.poll());       //从表格中获取教师页面

        //爬取教师页面
        while(!urls.isEmpty()){
            CrawTeacherInfo2014302580136(urls.poll());
        }
        endTime = System.currentTimeMillis();
    }

    //多线程爬取
    public void runWithMultiThreads(){
        InitCrawler();
        startTime = System.currentTimeMillis();
        CreateThreads();                //创建线程

        //从表格中爬取教师页面
        thread_pageReader.start();
        //等待爬取到教师页面
        try {
            while(urls.isEmpty()) {
                Thread.sleep(100);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        //让空闲线程尝试爬取教师页面
        while(!urls.isEmpty()){
            for(int i = 0; i < thread_inforeaders.length; ++i){
                if(thread_inforeaders[i].getState() == Thread.State.TERMINATED){
                    thread_inforeaders[i] = new CrawlerThread();
                    thread_inforeaders[i].start();
                }
            }
        }

        //等待各线程结束
        for(int i = 0; i < thread_inforeaders.length; ++i){
            while(thread_inforeaders[i].getState() != Thread.State.TERMINATED)
                ;
            continue;
        }

        endTime = System.currentTimeMillis();
    }

    public int getSuccessRead() {
        return successRead;
    }

    public int getFailed_noInfo() {
        return failed_noInfo;
    }

    public int getFailed_disconnect() {
        return failed_disconnect;
    }

    public long getRunTime(){
        return endTime - startTime;
    }

    //初始化爬取程序
    private void InitCrawler(){
        originUrl = "http://person.zju.edu.cn/pro-1101.html";
        domain = "http://person.zju.edu.cn";
        currentPage = 1;
        maxPage = 0;
        successRead = 0;
        failed_disconnect = 0;
        failed_noInfo = 0;
        startTime = 0;
        endTime = 0;
        pages.clear();
        pages.offer(originUrl);
        urls.clear();
    }

    //创建线程
    private void CreateThreads(){
        thread_pageReader = new Thread(() -> {
            while(!pages.isEmpty()){
                GetTeacherUrls(pages.poll());
            }
        });

        thread_inforeaders = new CrawlerThread[10];
        for(int i = 0; i < thread_inforeaders.length; ++i){
            thread_inforeaders[i] = new CrawlerThread();
            thread_inforeaders[i].start();
        }
    }

    //从表格中读取教师页面url
    private void GetTeacherUrls(String page) {
        Document doc = null;
        try {
            doc = Jsoup.connect(page).get();
        }
        catch (IOException e){
            e.printStackTrace();
        }

        //获取表格节点位置
        Element teacherTable = doc.getElementsByClass("tab_blue").get(0);
        Elements teachers = teacherTable.getElementsByTag("tr");

        //读取表格中的url
        ReadPage(teachers);
    }

    private void ReadPage(Elements teachers){
        for (Element teacher : teachers) {
            //检查是否取得了要求数量的教师url
            if(urls.size() >= maxNumber){
                return;
            }

            Elements row_urls = teacher.getElementsByClass("zhishi");
            if (row_urls.isEmpty()) {
                continue;
            }

            //最后一个url为下一表格页的url
            if (teacher == teachers.last()) {
                Element pageInfo = teacher;
                if(0 == maxPage){
                    maxPage = Integer.parseInt(pageInfo.getElementById("form1")
                            .getElementsByTag("font").get(2)
                            .text());
                }
                ++currentPage;
                if(currentPage < maxPage + 1){
                    pages.offer(originUrl + "?count=&sort=&page=" + currentPage);
                }
            }
            //否则为教师页面的url
            else{
                Element url = row_urls.get(0);
                urls.offer(url.attr("href"));
            }
        }
    }

    //抓取教师个人信息
    private void CrawTeacherInfo2014302580136(String url){
        //connect to url
        Document doc;
        try {
            doc = Jsoup.connect(url).get();
        }
        //两次尝试连接教师页面
        catch (IOException e){
            try {
                doc = Jsoup.connect(url).get();
            }
            catch (IOException el){
                synchronized (failed_disconnect) {
                    ++failed_disconnect;
                }
                return;
            }
        }

        TeacherInfo2014302580136 teacher = new TeacherInfo2014302580136();

        //读取基本信息和详细信息
        if(!ReadBasicInfo(doc, teacher) || !ReadOtherInfo(doc, teacher)){
            synchronized (failed_noInfo) {
                ++failed_noInfo;
            }
            return;
        }

        synchronized (successRead) {
            ++successRead;
        }

        //将信息写入Mysql
        teacher.WriteToMysql();
    }

    //读取基本信息
    private boolean ReadBasicInfo(Document doc, TeacherInfo2014302580136 teacher){
        //获取基本信息所在节点
        Element basicInfos = doc.getElementById("Side_BasicInfo");
        if(basicInfos == null){
            return false;
        }

        Elements infos = basicInfos.getElementsByTag("li");
        for(Element info : infos){
            String text = info.text();
            int beginPos = text.indexOf("：");
            if(text.contains("姓名")){
                String name = info.text().substring(beginPos + 1);
                if(name.isEmpty()){
                    return false;
                }
                teacher.setName(name);
                continue;
            }
            if(text.contains("单位")){
                teacher.setMaster(info.text().substring(beginPos + 1));
                continue;
            }
            if(text.contains("职称")){
                teacher.setLevel(info.text().substring(beginPos + 1));
                continue;
            }
        }
        return true;
    }

    //读取详细信息
    public boolean ReadOtherInfo(Document doc, TeacherInfo2014302580136 teacher){
        Elements mainInfos = doc.getElementsByClass("itemContent");
        if(mainInfos.size() < 3){
            return false;
        }

        Element brief = mainInfos.get(0);
        Element target = mainInfos.get(1);
        Element contacts = mainInfos.get(2);

        if(!brief.getElementsByTag("p").isEmpty()){
            teacher.setBrief(brief.getElementsByTag("p").get(0).text());
        }
        else{
            teacher.setBrief(brief.text());
        }
        if(!target.getElementsByTag("p").isEmpty()){
            teacher.setTarget(target.getElementsByTag("p").get(0).text());
        }
        else{
            teacher.setTarget(target.text());
        }

        String contacts_text = contacts.text();
        Pattern pattern_phone = Pattern.compile("([0-9]{3,4}-)*(([0-9])+\\s?)+");
        Pattern pattern_email = Pattern.compile("[a-zA-Z0-9]+@([a-zA-Z0-9].)*[a-zA-Z0-9]+");
        Matcher phone_matcher = pattern_phone.matcher(contacts_text);
        Matcher email_matcher = pattern_email.matcher(contacts_text);
        if(phone_matcher.find()){
            if(phone_matcher.group().length() > 7) {
                teacher.setPhone(phone_matcher.group());
            }
        }
        if(email_matcher.find()){
            teacher.setEmail(email_matcher.group());
        }

        return true;
    }
}
