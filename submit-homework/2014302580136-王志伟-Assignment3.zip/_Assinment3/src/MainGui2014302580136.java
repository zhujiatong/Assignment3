import java.awt.*;

/**
 * Created by inksmallfrog on 15-11-5.
 */
public class MainGui2014302580136 {
    public static void main(String[] args){
        EventQueue.invokeLater(() -> new SQLConnectorGui2014302580136());
    }
}
