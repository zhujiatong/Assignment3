/**
 * Created by inksmallfrog on 15-11-5.
 */
public class TeacherInfo2014302580136 {
    private String name;        //姓名
    private String master;      //专业
    private String level;       //职称
    private String brief;       //简介
    private String target;      //研究方向
    private String phone;       //电话
    private String email;       //邮箱

    public void setName(String _name){
        name = _name;
    }

    public String getName() {
        return name;
    }

    public void setMaster(String _master){
        master = _master;
    }

    public String getMaster() {
        return master;
    }

    public void setLevel(String _level){
        level = _level;
    }

    public String getLevel() {
        return level;
    }

    public void setBrief(String _brief){
        brief = _brief.replace("\"", "\\\"");
    }

    public String getBrief() {
        return brief;
    }

    public void setTarget(String _target){
        target = _target.replace("\"", "\\\"");
    }

    public String getTarget() {
        return target;
    }

    public void setPhone(String _phone){
        phone = _phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setEmail(String _email){
        email = _email;
    }

    public String getEmail() {
        return email;
    }

    /*public void Print(){
        System.out.println("name: " + name);
        System.out.println("master: " + master);
        System.out.println("level: " + level);
        System.out.println("brief: " + brief);
        System.out.println("target: " + target);
        System.out.println("phone: " + phone);
        System.out.println("email: " + email);
    }*/

    //写入数据库
    public void WriteToMysql(){
        MysqlConnector2014302580136.getInstance().Insert(this);
    }
}
