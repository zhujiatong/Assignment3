import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Jason_Wei on 2015/11/2.
 */
public class Main2014302580276
{
    static ArrayList<String> list = null;
    static long startTime = 0;
    static boolean failedParsing = false;

    private static ArrayList<String> getTeacherList(String infoURL) throws Exception
    {
        ArrayList<String> list = new ArrayList<>();
        String result = "";

        URL url = new URL(infoURL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("GET");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(20000);

        BufferedReader bufferedReader = null;
        try
        {
            bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
        } catch (Exception e)
        {
            throw e;
        }

        String line = "";

        while (line != null)
        {
            result += line;
            line = bufferedReader.readLine();
        }
        bufferedReader.close();

        Pattern pattern = Pattern.compile("<a href=\"(/teacher/detail\\?id=\\d+&dp=0)\" >");
        Matcher matcher = pattern.matcher(result);
        while (matcher.find())
        {
            list.add("http://cs.hust.edu.cn" + matcher.group(1));
        }

        return list;
    }

    public static void main(String[] args)
    {
        JFrame window = new JFrame("TeacherInfoSpider v0.0.1");

        window.setResizable(false);  //window's size can't change

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500, 500);

        window.setVisible(true);
        window.setLayout(null);   //absolute layout

        JButton multiThread = new JButton();
        multiThread.setText("Multiple Thread");
        window.add(multiThread);
        multiThread.setBounds(162, 90, 170, 50);
        multiThread.setFocusPainted(false);
        multiThread.setEnabled(false);

        JButton singleThread = new JButton();
        singleThread.setText("Single Thread");
        window.add(singleThread);
        singleThread.setBounds(162, 180, 170, 50);
        singleThread.setFocusPainted(false);
        singleThread.setEnabled(false);

        JButton save = new JButton();
        save.setText("Save To Database");
        window.add(save);
        save.setBounds(162, 270, 170, 50);
        save.setFocusPainted(false);
        save.setEnabled(false);

        JProgressBar progressBar = new JProgressBar();
        window.add(progressBar);
        progressBar.setMaximum(100);
        progressBar.setValue(0);
        progressBar.setBounds(100, 360, 300, 20);
        progressBar.setVisible(false);

        JLabel jLabel = new JLabel();
        window.add(jLabel);
        jLabel.setBounds(0, 380, 50, 20);
        jLabel.setText("Log: ");

        JTextArea output = new JTextArea();
        window.add(output);
        output.setBounds(0, 400, 500, 100);
        output.setAutoscrolls(true);
        output.setEditable(false);
        output.setText("");

        output.setText(output.getText() + "Begin parsing all teachers' homepages URLs...\n");

        try
        {
            list = getTeacherList("http://cs.hust.edu.cn/teacher/index?dp=0");
        } catch (Exception e)
        {
            //deal with connection failure
            failedParsing = true;
            output.setText(output.getText() + "Failed to parse teachers' homepage URLs!!!\n");
        }

        if (!failedParsing)
        {
            output.setText(output.getText() + "Finish parsing all teachers' url\n");
        }

        multiThread.setEnabled(true);
        singleThread.setEnabled(true);


        multiThread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                multiThread.setEnabled(false);
                singleThread.setEnabled(false);
                save.setEnabled(false);

                progressBar.setVisible(true);

                progressBar.setMaximum(list.size());

                TeachersInfoStorage2014302580276.setOnNumChange(new TeachersInfoStorage2014302580276.OnNumChange() {
                    @Override
                    public void onNumChange() {
                        progressBar.setValue(TeachersInfoStorage2014302580276.getInfo().size());
                    }
                });

                TeachersInfoStorage2014302580276.setMaxNum(list.size());

                TeachersInfoStorage2014302580276.setOnFinishCallback(new TeachersInfoStorage2014302580276.FinishCallback() {
                    @Override
                    public void onFinish() {

                        save.setEnabled(true);
                        multiThread.setEnabled(true);
                        singleThread.setEnabled(true);

                        progressBar.setValue(0);

                        progressBar.setVisible(false);

                        output.setText(output.getText() + "Multiple thread(30 threads) take time: " + (System.currentTimeMillis() - startTime) + "ms\n");
                    }
                });

                startTime = System.currentTimeMillis();

                ExecutorService executorService = Executors.newFixedThreadPool(30);
                for (String s : list) {
                    executorService.execute(new GetInfoThread2014302580276(s));
                }
                executorService.shutdown();
            }
        });

        singleThread.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                multiThread.setEnabled(false);
                singleThread.setEnabled(false);
                save.setEnabled(false);

                progressBar.setVisible(true);

                progressBar.setMaximum(list.size());

                SingleThreadStorage2014302580276.setOnNumChange(new SingleThreadStorage2014302580276.OnNumChange() {
                    @Override
                    public void onNumChange() {
                        progressBar.setValue(SingleThreadStorage2014302580276.getInfo().size());
                    }
                });

                SingleThreadStorage2014302580276.setMaxNum(list.size());

                SingleThreadStorage2014302580276.setOnFinishCallback(new SingleThreadStorage2014302580276.FinishCallback() {
                    @Override
                    public void onFinish() {
                        save.setEnabled(true);
                        multiThread.setEnabled(true);
                        singleThread.setEnabled(true);

                        progressBar.setValue(0);

                        progressBar.setVisible(false);

                        output.setText(output.getText() + "Single thread take time: " + (System.currentTimeMillis() - startTime) + "ms\n");
                    }
                });

                startTime = System.currentTimeMillis();

                ExecutorService executorService1 = Executors.newSingleThreadExecutor();
                executorService1.execute(new GetInfoSingleThread2014302580276(list));
                executorService1.shutdown();
            }
        });

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {

                save.setEnabled(false);

                DBWriter2014302580276.setOnFinishListener(new DBWriter2014302580276.OnFinishWriting() {
                    @Override
                    public void onFinishWriting() {

                        output.setText("All teachers' info has been written to database!\n");
                        save.setEnabled(true);
                    }
                });

                if (TeachersInfoStorage2014302580276.getInfo().size() != 0)
                {
                    try
                    {
                        DBWriter2014302580276.writeToDB(TeachersInfoStorage2014302580276.getInfo());
                    } catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                else if (SingleThreadStorage2014302580276.getInfo().size() != 0)
                {
                    try
                    {
                        DBWriter2014302580276.writeToDB(SingleThreadStorage2014302580276.getInfo());
                    } catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                else
                {
                    save.setEnabled(true);
                    output.setText("Nothing can be written to database!!!");
                }
            }
        });
    }
}
