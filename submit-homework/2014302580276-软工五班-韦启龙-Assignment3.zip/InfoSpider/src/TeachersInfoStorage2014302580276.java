import java.util.ArrayList;

/**
 * Created by Jason_Wei on 2015/11/2.
 */
public class TeachersInfoStorage2014302580276
{
    private static ArrayList<String[]> info = new ArrayList<>();

    private static int maxNum = 0;

    private static FinishCallback callback = null;
    private static OnNumChange onNumChange = null;

    private static int count = 0;

    public synchronized static void addInfo(String[] newInfo)
    {
        info.add(newInfo);

        count++;

        if (onNumChange != null)
            onNumChange.onNumChange();

        if (count == maxNum)
        {
            callback.onFinish();
            callback = null;

            onNumChange = null;
        }
    }

    public synchronized static void setMaxNum(int num)
    {
        maxNum = num;
    }

    public synchronized static ArrayList<String[]> getInfo()
    {
        return info;
    }

    public static void setOnFinishCallback(FinishCallback c)
    {
        callback = c;
    }

    public interface FinishCallback
    {
        void onFinish();
    }

    public interface OnNumChange
    {
        void onNumChange();
    }

    public static void setOnNumChange(OnNumChange c)
    {
        onNumChange = c;
    }
}


class SingleThreadStorage2014302580276
{
    private static ArrayList<String[]> info = new ArrayList<>();

    private static int maxNum = 0;

    private static FinishCallback callback = null;
    private static OnNumChange onNumChange = null;

    private static int count = 0;

    public static void addInfo(String[] newInfo)
    {
        info.add(newInfo);

        count++;

        if (onNumChange != null)
            onNumChange.onNumChange();

        if (count == maxNum)
        {
            callback.onFinish();
            callback = null;

            onNumChange = null;
        }
    }

    public static void setMaxNum(int num)
    {
        maxNum = num;
    }

    public static ArrayList<String[]> getInfo()
    {
        return info;
    }

    public static void setOnFinishCallback(FinishCallback c)
    {
        callback = c;
    }

    public interface FinishCallback
    {
        void onFinish();
    }

    public interface OnNumChange
    {
        void onNumChange();
    }

    public static void setOnNumChange(OnNumChange c)
    {
        onNumChange = c;
    }
}
