import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

/**
 * Created by Jason_Wei on 2015/11/3.
 */
public class GetInfoThread2014302580276 implements Runnable
{
    private String infoUrl = "";
    public GetInfoThread2014302580276(String infoUrl)
    {
        this.infoUrl = infoUrl;
    }

    @Override
    public void run()
    {
        String[] arr = new String[6];
        String result = "";

        URL url = null;
        try
        {
            url = new URL(infoUrl);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        HttpURLConnection connection = null;
        try
        {
            connection = (HttpURLConnection) url.openConnection();
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        try
        {
            connection.setRequestMethod("GET");
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(20000);

        BufferedReader bufferedReader = null;
        try
        {
            bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        String line = "";
        while (line != null)
        {
            result += line;
            line = null;
            try
            {
                line = bufferedReader.readLine();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        try
        {
            bufferedReader.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        Document document = null;
        try
        {
            document = Jsoup.parse(new ByteArrayInputStream(result.getBytes("UTF-8")), "UTF-8", "");
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        Element element = document.select("ul[class=teachul]").first();
        Iterator<Element> iterator = element.select("li").iterator();
        for (int i = 0; i < 4; i++)
        {
            arr[i] = iterator.next().text();
        }
        Document document1 = null;
        try
        {
            document1 = Jsoup.parse(new ByteArrayInputStream(result.replace("&nbsp;", "").getBytes("UTF-8")), "UTF-8", "");
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        Iterator<Element> iterator1 = document1.select("div[class=show_cont]").iterator();
        for (int i = 0; i < 2; i++)
        {
            arr[4 + i] = iterator1.next().text();
        }

        TeachersInfoStorage2014302580276.addInfo(arr);
    }
}
