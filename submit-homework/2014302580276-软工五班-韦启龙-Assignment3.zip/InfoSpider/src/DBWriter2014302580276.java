import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Created by Jason_Wei on 2015/11/3.
 */
public class DBWriter2014302580276
{
    private static String url = "jdbc:mysql://localhost:3306/teacher_info";
    private static String user = "root";
    private static String password = "rootpwd";

    private static OnFinishWriting onFinishWriting = null;

    public static void writeToDB(ArrayList<String[]> info) throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");

        Connection connection = DriverManager.getConnection(url, user, password);

        Statement statement = connection.createStatement();

        for (String[] arr : info)
        {
            String sql = "insert into teachersinfo(name,position,phone,email,background,research) values('" +
                    arr[0] + "','" + arr[1] + "','" + arr[2] + "','" + arr[3] + "','" + arr[4] + "','" + arr[5] + "')";

            statement.execute(sql);
        }

        if (onFinishWriting != null)
        {
            onFinishWriting.onFinishWriting();
            onFinishWriting = null;
        }
    }

    public interface OnFinishWriting
    {
        public void onFinishWriting();
    }

    public static void setOnFinishListener(OnFinishWriting onFinishListener)
    {
        onFinishWriting = onFinishListener;
    }
}
