import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580125 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
            
		//���߳�
		SingleThread singleThread=new SingleThread();
		Thread st=new Thread(singleThread);
		st.start();
		//���߳�
		MultiThread multiThread0=new MultiThread();
		Thread mt0=new Thread(multiThread0);
		mt0.start();
		MultiThread multiThread1=new MultiThread();
		Thread mt1=new Thread(multiThread1);
		mt1.start();
		MultiThread multiThread2=new MultiThread();
		Thread mt2=new Thread(multiThread2);
		mt2.start();
		MultiThread multiThread3=new MultiThread();
		Thread mt3=new Thread(multiThread3);
		mt3.start();
		MultiThread multiThread4=new MultiThread();
		Thread mt4=new Thread(multiThread4);
		mt4.start();
		MultiThread multiThread5=new MultiThread();
		Thread mt5=new Thread(multiThread5);
		mt5.start();
		MultiThread multiThread6=new MultiThread();
		Thread mt6=new Thread(multiThread6);
		mt6.start();
		MultiThread multiThread7=new MultiThread();
		Thread mt7=new Thread(multiThread7);
		mt7.start();
		MultiThread multiThread8=new MultiThread();
		Thread mt8=new Thread(multiThread8);
		mt8.start();
		
		
	}
	
}
//���߳���
class SingleThread implements Runnable{
	long start = System.currentTimeMillis();
	static int i;
	public void run(){
		try {
			PrintWriter output = new PrintWriter("Teacher.txt");
			for(i=0;i<=8;i++)
				{
				Crawl(i);
				//System.out.println(Crawl(i));
				//output.println("kkkojh");
				output.println(Crawl(i));
				}
		output.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	long end = System.currentTimeMillis();
	    System.out.print("���߳�����ʱ��Ϊ��");
		System.out.println(end-start);
	}
	
	public static String Crawl (int i) throws IOException{
		Document doc=Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=161"+i)
				.data("query","Java")
				.userAgent("I'm jsoup")
				.cookie("auth","token")
				.timeout(100000)
				.post();
		//Document doc=Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=161"+i).get();
		
		//PrintWriter output=new PrintWriter("Teacher.txt");
		
		Elements t=doc.getElementsByTag("li");
		Element t1= t.get(50);
		Element t2=t.get(52);
		Element t3=t.get(53);
		Element t4=t.get(54);
		Element t5=t.get(55);
		Element t6=t.get(57);
		String Name=t1.text();
		String Intro=t2.text()+","+t3.text()+","+t4.text();
		String Tel=t5.text();
		String Email=t6.text();
		String m=Name+" "+Intro+" "+Tel+" "+Email;
		  return m;
		//output.println(Name);
		//output.close();
		
	/*	System.out.println(Name);
		System.out.println(Intro);
		System.out.println(Tel);
		System.out.println(Email);*/
	  }
	
}


//���߳���
class MultiThread implements Runnable{
	static int j=-1;
	static int ss=-1;
	long start1 = System.currentTimeMillis();
	final  long start=start1;
	public void run(){
		try {
			j++;
				Crawl(j);
				//t=Crawl(j);
			//j++;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(ss==8){
		long end = System.currentTimeMillis();
		System.out.print("���߳�����ʱ��Ϊ��");
			System.out.println(end-start);
		}
		
	}
	public static int Crawl (int i) throws IOException{
		//j++;

		Document doc=Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=161"+i)
				.data("query","Java")
				.userAgent("I'm jsoup")
				.cookie("auth","token")
				.timeout(100000)
				.post();
		//Document doc=Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid=161"+i).get();
		Elements t=doc.getElementsByTag("li");
		Element t1= t.get(50);
		Element t2=t.get(52);
		Element t3=t.get(53);
		Element t4=t.get(54);
		Element t5=t.get(55);
		Element t6=t.get(57);
		String Name=t1.text();
		String Intro=t2.text()+","+t3.text()+","+t4.text();
		String Tel=t5.text();
		String Email=t6.text();
		/*System.out.println(Name);
		System.out.println(Intro);
		System.out.println(Tel);
		System.out.println(Email);*/
		ss++;
		return ss;
	  }
	
}
