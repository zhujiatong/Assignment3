import java.sql.SQLException;


public class Main2014302580205 {
	public static void main(String[]argc) throws ClassNotFoundException, SQLException, InterruptedException{
		String url=new String("http://www.wpi.edu/academics/facultydir/facultyname.html");
		final Crawler2014302580205 crawler=new Crawler2014302580205(url);
		long time1;
		
		//����Ϊ���̲߳���
		Thread t1=new Thread(){
			@Override
			public void run(){
				try {
					crawler.pushToBuffer();
				} catch (InterruptedException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		};
		Thread t2=new Thread(){
			@Override
			public void run(){
				try {
					crawler.outToDataBase();
				} catch (ClassNotFoundException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		};
		time1=System.currentTimeMillis();
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		time1=System.currentTimeMillis()-time1;
		System.out.printf("���߳�ʱ�䣺%d\n",time1);
		
		//����Ϊ���߳�
		time1=System.currentTimeMillis();
		crawler.pushToBufferSingle();
		long time2=System.currentTimeMillis()-time1;
		//System.out.printf("���̲߳���ʱ�䣺%d\n",time2);
		//crawler.getBuffer().outToConsole();
		crawler.outToDataBaseSingle();
		time1=System.currentTimeMillis()-time1;
		System.out.printf("���߳�ʱ�䣺%d\n",time1);
		

	}
}
