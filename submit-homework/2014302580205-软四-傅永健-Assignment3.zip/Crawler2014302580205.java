import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.mysql.jdbc.Buffer;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;


public class Crawler2014302580205 {
	//����
	public static final int NUMBER_OF_TEACHER=500;
	//��Ա����
	private MyBuffer2014302580205 m_buffer;
	private String m_url;
	private String m_baseHTML;
	private Teacher2014302580205 [] m_teacher;
	
	//��Ա����
	//������
	public Crawler2014302580205(String url){
		m_url=new String(url);
		m_buffer=new MyBuffer2014302580205(800);
		m_baseHTML=HttpRequest.get(m_url).body();
		setTeacherURL();
	}
	//��ȡ��ʦ���ݲ���ջ�����̣߳�
	public void pushToBufferSingle() throws InterruptedException{
		int count=0;
		m_buffer=new MyBuffer2014302580205(NUMBER_OF_TEACHER);
		while(m_teacher[count]!=null){
			m_teacher[count].getDataAndAtrribute();
			m_buffer.push(m_teacher[count]);
			count++;
			//System.out.print("4 ");
		}
	}
	//��ȡ��ʦ���ݲ���ջ
		public void pushToBuffer() throws InterruptedException{
			int count=0;
			ExecutorService es=Executors.newFixedThreadPool(10);
			while(m_teacher[count]!=null){
				es.execute(new CrawlerThread(count));
				count++;
			}
		}
	//�������ݿⲢ�����ݼ������ݿ�
	public void outToDataBase() throws ClassNotFoundException, SQLException, InterruptedException{
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection connection=DriverManager.getConnection(StaticString2014302580205.URL,
				StaticString2014302580205.USER_NAME,StaticString2014302580205.PASSWORD);
		java.sql.PreparedStatement ps= connection.prepareStatement(StaticString2014302580205.INSTRUCT);
		int count=0;
		while(m_teacher[count]!=null){
			while(m_buffer.isempty()!=true){
				Teacher2014302580205 temp=m_buffer.pop();
				ps.setObject(1,temp.getName());
				ps.setObject(2, temp.getPhoneNumber());
				ps.setObject(3, temp.getEmail());
				ps.setObject(4, temp.getIntroduction());
				ps.setObject(5, temp.getArea());
				ps.executeUpdate();
				count++;
				//System.out.print("2 ");
			}
			
		}
		ps.close();
		connection.close();
	}
	//�������ݿⲢ�����ݼ������ݿ⣨���̣߳�
		public void outToDataBaseSingle() throws ClassNotFoundException, SQLException, InterruptedException{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connection=DriverManager.getConnection(StaticString2014302580205.URL,
					StaticString2014302580205.USER_NAME,StaticString2014302580205.PASSWORD);
			java.sql.PreparedStatement ps= connection.prepareStatement(StaticString2014302580205.INSTRUCT);
			//int count=0;
			while(m_buffer.isempty()!=true){
				Teacher2014302580205 temp=m_buffer.pop();
				ps.setObject(1,temp.getName());
				ps.setObject(2, temp.getPhoneNumber());
				ps.setObject(3, temp.getEmail());
				ps.setObject(4, temp.getIntroduction());
				ps.setObject(5, temp.getArea());
				ps.executeUpdate();
				//System.out.print("3 ");
				//count++;
			}
			ps.close();
			connection.close();
		}
	//���ԣ���ȡbuffer
	public MyBuffer2014302580205 getBuffer(){
		return m_buffer;
	}
	
	
	
	//���ߺ���
	//����ԭʼ�����html�ļ���ȷ��ÿһ����ʦ��teacherURLֵ
	private void setTeacherURL(){
		m_teacher=new Teacher2014302580205[NUMBER_OF_TEACHER];
		//����html
		Document doc=Jsoup.parse(m_baseHTML);
		//��ȡclassֵΪthird��div��ǩ��Ԫ�أ���С��Χ
		Elements element=doc.select("div.third");
		//������С��Χ������ݣ���ȡ��������Ԫ��
		String containOfP=new String(element.toString());
		//System.out.print(containOfP);//����
		doc=Jsoup.parse(containOfP,m_url);
		Elements link=doc.select("a");
		//��ȡlink�����е��������ԣ�ʵ����teacher
		int count =0;
		for(Iterator i=link.iterator();i.hasNext()&&count<=1000;){
			String teacherURL=((Element)(i.next())).attr("abs:href");
			if(teacherURL!=" "&&teacherURL!=""){
				m_teacher[count]=new Teacher2014302580205(teacherURL);
				count++;
			}
		}
	}
	//��ָ��Ԫ��Ͷ��buffer
	private void putAnElementToBuffer(int count) throws InterruptedException{
		m_teacher[count].getDataAndAtrribute();
		m_buffer.push(m_teacher[count]);
	}
	//�ڲ���
	private class CrawlerThread implements Runnable{
		private int m_count;
		public CrawlerThread(int count) {
			m_count=count;
		}
		@Override
		public void run() {
			try {
				putAnElementToBuffer(m_count);
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}			
		}
		
	}
}









