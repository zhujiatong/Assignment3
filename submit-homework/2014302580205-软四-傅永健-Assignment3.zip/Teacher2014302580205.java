import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Teacher2014302580205 {
	private String m_teacherURL;
	private String m_phoneNumber;
	private String m_email;
	private String m_name;
	private String m_introduction;
	private String m_area;
	//��Ա����
	//������
	public Teacher2014302580205(String teacherURL){
		m_teacherURL=new String(teacherURL);
		//getDataAndAtrribute();
	}
	//��ȡurlID
	public String getTeacherURL(){
		return m_teacherURL;
	}
	//��ȡphoneNumber
	public String getPhoneNumber(){
		return m_phoneNumber;
	}
	//��ȡemail
	public String getEmail(){
		return m_email;
	}
	//��ȡname
	public String getName(){
		return m_name;
	}
	//��ȡintroduction
	public String getIntroduction(){
		return m_introduction;
	}
	//��ȡarea
	public String getArea(){
		return m_area;
	}
	//���ԣ������������
	public void outToConsole(){
		System.out.println(m_name);
		System.out.println(m_phoneNumber);
		System.out.println(m_email);
		System.out.println(m_area);
		System.out.println(m_introduction);
		System.out.println();
	}
	//��ȡ���ݲ���ȡ��������ֵ
	public void getDataAndAtrribute(){
		HttpRequest response=HttpRequest.get(m_teacherURL);
		String result=response.body();
		Document doc=Jsoup.parse(result);
		parseData(doc, result);
	}
	

	//���ߺ���
	//������������
	private void parseData(Document doc,String result){
		parseArea(doc);
		parseName(doc);
		parseEmail(doc);
		parseIntroduction(doc);
		parsePhoneNumber(result);
	}

	//����ȡ�����н�����name
	private void parseName(Document doc){
		Element name=doc.select("h2").first();
		m_name=new String(name.text());
	}
	//����ȡ�����н�����email
	private void parseEmail(Document doc){
		Elements lessenElement=doc.select("p");
		String result=lessenElement.text();
		
		
		Pattern emailPattern=Pattern.compile("[a-z0-9A-Z]+@([a-z0-9A-Z]+\\.)+[a-z0-9A-Z]{2,3}");
		Matcher matcher=emailPattern.matcher(result);
		if(matcher.find()){
			m_email=matcher.group();
		}
	}
	//����ȡ�����н�����phoneNumber
	private void parsePhoneNumber(String result){
		Pattern phonePattern=Pattern.compile("\\+[0-9]\\-[0-9]{3}\\-[0-9]{3}\\-[0-9]{4}");
		Matcher matcher=phonePattern.matcher(result);
		if(matcher.find()){
			m_phoneNumber=new String(matcher.group());
		}
	}
	//����ȡ�����н�����introduction
	private void parseIntroduction(Document doc){
		doc.select("div#profile").val(" ");
		Elements introduction=doc.select("p");
		
		String information =introduction.get(2).text();
		m_introduction=new String(information);
	}
	//����ȡ�����н�����area
	private void parseArea(Document doc){
		Elements area=doc.select("ul.titles");
		String informationLessen=area.toString();
		Document docLesson=Jsoup.parse(informationLessen);
		area=docLesson.select("a");
		m_area=new String(area.text());
	}
}
