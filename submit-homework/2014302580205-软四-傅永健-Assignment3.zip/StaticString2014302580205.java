
public class StaticString2014302580205 {
	public static String URL=new String("jdbc:mysql://localhost:3306/teacher");
	public static String USER_NAME=new String("root");
	public static String PASSWORD=new String("yongjian");
	public static String INSTRUCT=new String("insert into teachers(name,phoneNumber,email,introduction,area)"
			+ "value(?,?,?,?,?);");
}
