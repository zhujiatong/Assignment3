
public class MyBuffer2014302580205 {
	private Teacher2014302580205 [] m_teacher;
	private int m_maxCapability;
	private int m_top;
	
	//��Ա����
	//������
	public MyBuffer2014302580205(int numOfTeacher){
		m_teacher=new Teacher2014302580205[numOfTeacher];
		m_maxCapability=numOfTeacher;
		m_top=-1;
	}
	//�ж��Ƿ���
	public Boolean isFull(){
		if(m_top==m_maxCapability-1){
			return true;
		}else{
			return false;
		}
	}
	//�ж��Ƿ��ջ
	public Boolean isempty(){
		if(m_top==-1){
			return true;
		}else{
			return false;
		}
	}
	//��ջ
	public synchronized void push(Teacher2014302580205 teacher) throws InterruptedException{
		if(m_top==m_maxCapability-1){
			System.out.println("�����");
			wait();
			//return;
		}
		m_top++;
		m_teacher[m_top]=teacher;
		//m_teacher[m_top].getDataAndAtrribute();
		notify();
	}
	//��ջ
	public synchronized Teacher2014302580205 pop() throws InterruptedException{
		if(m_top==-1){
			System.out.println("��ջ��");
			wait();
			//return null;
		}
		m_top--;
		notify();
		return m_teacher[m_top+1];
	}
	//���ԣ������������
	public void outToConsole(){
		for(int i=0;i<=m_top;i++){
			m_teacher[i].outToConsole();
		}
	}
}
