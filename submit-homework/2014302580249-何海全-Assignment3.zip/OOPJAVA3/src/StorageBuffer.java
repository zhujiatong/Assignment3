
import java.util.concurrent.ArrayBlockingQueue;


public class StorageBuffer implements Buffer<String> {
	private final ArrayBlockingQueue<String> buffer;
	
	public StorageBuffer(int mSize){
		buffer = new ArrayBlockingQueue<String>(mSize);
	}
	public String read() throws InterruptedException
	{
		return buffer.take();
	}
	public void clearBuffer() throws InterruptedException
	{
		
	}

	public void push(String x) throws InterruptedException {
		buffer.put(x);
		
	}

	
}
