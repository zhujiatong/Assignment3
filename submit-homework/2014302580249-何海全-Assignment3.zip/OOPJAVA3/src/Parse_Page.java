
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;

public class Parse_Page {
	//�������ݿ��column���
	final Map<String,String> sqlColumns = new HashMap<String,String>();

	public Parse_Page(){
			
	}

	public Map<String,String> parse(String url){
		String response = HttpRequest.get(url).body();
		return parsePage(response);
	}
	public  Map<String,String> parsePage(String response){
		Document doc = Jsoup.parse(response);
		Elements details = doc.getElementsByClass("details");		
		Elements nameCard = details.not(".col-xs-12");
		
		
		//get professor's name
		String title = nameCard.first().getElementsByTag("h3").text();
		//Ϊ��sql���
		title = "'" + title + "'";
		//the str parsed by regular expression��
		String strToParse = nameCard.last().getElementsByTag("p").text();
		
		//get email
		Pattern emailPattern = Pattern.compile("[a-z]+@[a-z\\.]+");
		String email = parseReg(strToParse,emailPattern);
		email = "'" + email + "'";
		//get tel Number
		Pattern telPattern = Pattern.compile("\\d{7,11}");
		String telNum = parseReg(strToParse,telPattern);
		telNum = "'" + telNum + "'";
		//get brief introduce of the professor
		String introduce = "";
		Elements introduceModules = details.select(".col-md-12").last().children();
		for(Element mol : introduceModules){
			introduce += mol.getElementsByClass("szll_wz_bt").text()  + "\n";
			introduce += mol.getElementsByTag("p").text() + "\n\n";
		}
		introduce = "'" + introduce + "'";
		
		//print on the screen -- debug
		/*
		System.out.printf("title : " + title + "\n");
		System.out.printf("email : " + email+ "\n");
		System.out.printf("telNum : " + telNum+ "\n");
		System.out.printf("introduce : " + introduce);
		*/
		//store on the column
		sqlColumns.put("title", title);
		sqlColumns.put("email", email);
		sqlColumns.put("telNum", telNum);
		sqlColumns.put("introduce", introduce);
		
		//�������ݿ�
		return sqlColumns;
		
		
	}
	private String parseReg(String str,Pattern pattern){
		Matcher macther = pattern.matcher(str);
		String result = "��";
		if(macther.find()){
		
			result = macther.group();
		}
		return result;
	}

		
}
