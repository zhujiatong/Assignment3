
public interface Buffer <T> {
	public void push(T x) throws InterruptedException;
	public void clearBuffer() throws InterruptedException;
	public T read() throws InterruptedException;
}
