import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.Map;

public class Consumer extends Parse_Page implements Runnable{
	
	private final Buffer<String> storageBuffer;
	private final int cycleNum;
	
	//database related variables ���ݿ���ر���
	private Connection connection = null;
	private Statement statement = null; 
	private ResultSet resultSet = null;
	private DatabaseMetaData metadata = null;
	
	private static final String DB_URL = "jdbc:mysql://localhost/TEACHERS2?useUnicode=true&characterEncoding=UTF-8";
	
	//�û��� ����
	static final String USER = "hatsentsing";
    static final String PASS = "hatsentsing";
	public Consumer(Buffer<String> buffer,int num){
		cycleNum = num;
		storageBuffer = buffer;
		try {
			System.out.println("Connecting to a selected database...");
			connection = DriverManager.getConnection(DB_URL,USER,PASS);
			System.out.println("Connected database successfully...");	
			statement = connection.createStatement();
			//�鿴�Ƿ��Ѿ�����
			if(!checkIfTableExists("TEACHERS2_TABLE")){
				setupTable("TEACHERS2_TABLE");
			};
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("��ʼ��Consumerʱ����---1");
			try
			{
			resultSet.close();
			statement.close();
			connection.close();
			} // end try
			catch ( Exception exception )
			{
				exception.printStackTrace();
			}
			e.printStackTrace();
		}// end finally
	}
	public void run() {
		for(int i = 0; i < cycleNum; i ++){
			String response = null;
			try {
				response = storageBuffer.read();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(response == null) continue;
			store(parsePage(response));
		}	
	}
	private void store(Map<String,String> columns){
		String sql = "INSERT INTO TEACHERS2_TABLE (";
		String colNames = "";
		String values = "";
		for (Map.Entry<String, String> entry : columns.entrySet()) {  
			System.out.printf("%s : %s\n",entry.getKey(),entry.getValue());
		    colNames += (entry.getKey() + ",");
		    values += (entry.getValue() + ",");
		}  
		colNames = colNames.substring(0, colNames.length() - 1);
		values = values.substring(0, values.length() - 1);
		sql += colNames + ") VALUES ( " + values + " )";
		//INSERT INTO tableName  VALUES ( value1, value2, ��, valueN )
		try {
			statement.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.printf("�洢ĳ����ʦ��Ϣʱ����");
			e.printStackTrace();
			
		}
	}
	private boolean checkIfTableExists(String tbName){
		 
		try {
			metadata = connection.getMetaData();
			resultSet = metadata.getTables(null, null, tbName, null);
		    while (resultSet.next()) { 
		       System.out.println("�Ѿ����� already set up a table");
		       return true; 
		    }	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("����checkIfTableExists�׳��쳣");			
		} 
		System.out.println("��δ����");
		return false;
       
	}
	private void setupTable(String tbName){
		 String sql = "CREATE TABLE "+ tbName +
                 " (title VARCHAR(255), " +
                 " email VARCHAR(255), " + 
                 " telNum VARCHAR(255), " + 
                 " introduce TEXT )"; 
		 try {
			statement.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("����ʱ����");
			e.printStackTrace();
			try
			{
				resultSet.close();
				statement.close();
				connection.close();
			} // end try
			catch ( Exception exception )
			{
				exception.printStackTrace();
			} // end catch
		}
	}
}
