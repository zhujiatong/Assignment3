import java.net.URL;
import java.util.concurrent.ExecutorService;

import com.github.kevinsawicki.http.HttpRequest;
public class ExtractInfo implements Runnable{
	private final Buffer<String> storageBuffer;
	private final String url;
	public ExtractInfo(Buffer<String> buffer,String pageUrl){
		storageBuffer = buffer;
		url = pageUrl;
	}
	
	public void run() {
		String response = HttpRequest.get(url).body();
		try {
			storageBuffer.push(response);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
