package assignment3;

import java.io.File;

public class GetPage2012300070048 {

	private String fileName;
	public GetPage2012300070048(String htmlL) {
		HttpRequest requestL = new HttpRequest(htmlL, "GET");
		fileName = "D:/" + String.valueOf(getIdL(htmlL)) + ".html";
		requestL.receive(new File(fileName));
	}
	
	private int getIdL(String htmlL) {
		int startIdx = htmlL.lastIndexOf("/") + 1;
		int endIdx = htmlL.lastIndexOf(".");
		htmlL = htmlL.substring(startIdx, endIdx);
		return Integer.parseInt(htmlL);
	}

	public String getFilePath() {
		return fileName;
	}
}
