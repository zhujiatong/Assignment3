package assignment3;

public class TeacherInfo2012300070048 {

	private String name;
}
