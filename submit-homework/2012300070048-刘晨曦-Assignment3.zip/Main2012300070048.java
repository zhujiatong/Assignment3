package assignment3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main2012300070048 {
	private static void clearL() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connL = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/teacherInformationL","root","Mysql0119");
		PreparedStatement statementL=null;
		
		String sqlL = "drop table if exists professorinfol";
		statementL = connL.prepareStatement(sqlL);
		statementL.executeUpdate(sqlL);
		statementL.close();
		connL.close();
	}
	
	private static void createTableL() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connL = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/teacherinformationl","root","Mysql0119");
		PreparedStatement statementL=null;
		
		
		String sqlL = "create table professorInfoL( " + "idL int(5) auto_increment not null primary key, " + "nameL varchar(10) not null,"
				+ "introL varchar(200) not null," + "researchL varchar(200) not null," + " phoneL varchar(50) not null," + "emailL varchar(50) not null);";
   		statementL = connL.prepareStatement(sqlL);
		statementL.executeUpdate(sqlL);
		statementL.close();
		connL.close();
	}
		
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		
		clearL();
		createTableL();
		// ���̲߳���
		long singleThreadBeginL=System.currentTimeMillis();
		GetHtml2012300070048 allHtmlL = new GetHtml2012300070048();
		for (String eleL : allHtmlL.getHtmlListL()) {
			GetPage2012300070048 htmlPageL = new GetPage2012300070048(eleL);
			OneTeacherInfo2012300070048 teacherL = new OneTeacherInfo2012300070048(htmlPageL.getFilePath());
			teacherL.writeInDatabaseL();
		}
		long singleThreadEndL=System.currentTimeMillis();
		System.out.println("���߳�ʱ��: " + (singleThreadEndL - singleThreadBeginL) + "ms");
		
		clearL();
		createTableL();
		// ���̲߳���
		long multiThreadBeginL=System.currentTimeMillis();
		GetHtml2012300070048 anotherAllHtmlL = new GetHtml2012300070048();
		Thread r1L = new Thread() {
			@Override
			public void run() {
				for (int counter = 0; counter < anotherAllHtmlL.getSizeL()/3; counter++)
				{
					GetPage2012300070048 htmlPageL = new GetPage2012300070048(anotherAllHtmlL.getHtmlListL().get(counter));
					OneTeacherInfo2012300070048 teacherL = new OneTeacherInfo2012300070048(htmlPageL.getFilePath());
					try {
						teacherL.writeInDatabaseL();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					
			}
		};
		
		Thread r2L = new Thread() {
			@Override
			public void run() {
				for (int counter = anotherAllHtmlL.getSizeL()/3; counter < (anotherAllHtmlL.getSizeL()/3)*2; counter++)
				{
					GetPage2012300070048 htmlPageL = new GetPage2012300070048(anotherAllHtmlL.getHtmlListL().get(counter));
					OneTeacherInfo2012300070048 teacherL = new OneTeacherInfo2012300070048(htmlPageL.getFilePath());
					try {
						teacherL.writeInDatabaseL();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					
			}
		};
		
		
		Thread r3L = new Thread() {
			@Override
			public void run() {
				for (int counter = (anotherAllHtmlL.getSizeL()/3)*2; counter < anotherAllHtmlL.getSizeL(); counter++)
				{
					GetPage2012300070048 htmlPageL = new GetPage2012300070048(anotherAllHtmlL.getHtmlListL().get(counter));
					OneTeacherInfo2012300070048 teacherL = new OneTeacherInfo2012300070048(htmlPageL.getFilePath());
					try {
						teacherL.writeInDatabaseL();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					
			}
		};
		
		ExecutorService myExecutorL = Executors.newCachedThreadPool();
		myExecutorL.execute(r1L); // start task1
		myExecutorL.execute(r2L); // start task2
		myExecutorL.execute(r3L); // start task3
		
		myExecutorL.shutdown();
		
		while (true) {
			if(myExecutorL.isTerminated())
				break;
		}
		long multiThreadEndL=System.currentTimeMillis();
		System.out.println("���߳�ʱ��: " + (multiThreadEndL - multiThreadBeginL) + "ms");
	}
}
