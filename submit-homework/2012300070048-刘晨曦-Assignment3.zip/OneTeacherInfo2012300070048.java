package assignment3;


import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class OneTeacherInfo2012300070048 {
	private Document teacherDocL;
	
	public OneTeacherInfo2012300070048(String htmlPathL) {
		File inputL = new File(htmlPathL);
		teacherDocL = null;
		try {
			teacherDocL = Jsoup.parse(inputL,"UTF-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private String deleteTitleL(String sL) {
		int idxL = sL.indexOf("��") + 1;
		return sL.substring(idxL);
	}
	public String getNameL() {
		Element nameL = teacherDocL.select("div.tit").first();
		return nameL.text();
	}
	
	public String getIntroL() {
		Element introL = teacherDocL.getElementsByTag("p").get(1);		
		return deleteTitleL(introL.text());
	}
	
	// get research area
	public String getResearchL() {
		Element researchL = teacherDocL.getElementsByTag("p").get(3);
		return deleteTitleL(researchL.text());
	}
	
	// get telephone number
	public String getPhoneNumberL() {
		Elements teacherL = teacherDocL.getElementsByTag("p");
		ListIterator<Element> infoListL = teacherL.listIterator();
		int counter = 0;
		while(infoListL.hasNext()) {
			if (counter > 7)
				break;
			counter++;
			Pattern phonePatternL = Pattern.compile("-?[0-9]{8,11}");
			Element phoneEleL = infoListL.next();
			String phoneNumberL = phoneEleL.text();
			Matcher phoneMatcherL = phonePatternL.matcher(phoneNumberL);
			if (phoneMatcherL.find()) {
				return deleteTitleL(phoneEleL.text());
			}
				
		}
		return "û���ҵ��绰����";
	}
	
	// get e-mail
	public String getEmailL() {
		Elements teacherL = teacherDocL.getElementsByTag("p");
		ListIterator<Element> infoListL = teacherL.listIterator();
		while(infoListL.hasNext()) {
			Pattern emailPatternL = Pattern.compile("@[a-zA-Z0-9]{2,}" );
			Element emailEleL = infoListL.next();
			String emailL = emailEleL.text();
			Matcher emailMatcherL = emailPatternL.matcher(emailL);
			if (emailMatcherL.find()) {
				return deleteTitleL(emailEleL.text());
			}
			
		}
		return "û���ҵ�email";
	}
	
	public void writeInDatabaseL() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection connL = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/teacherInformationL","root","Mysql0119");
		PreparedStatement statementL=null;
		
		String sqlL = "insert into professorInfoL(nameL, introL, researchL, phoneL, emailL) values(\"" + 
					getNameL() + "\",\"" + getIntroL() + "\",\"" + getResearchL() + "\",\"" + getPhoneNumberL() + "\",\"" + getEmailL() + "\");";
		statementL = connL.prepareStatement(sqlL);
		statementL.executeUpdate(sqlL);
		statementL.close();
		connL.close();
	}
	
}
