package assignment3;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GetHtml2012300070048 {
	
	private ArrayList<Integer> teacherIdL;
	private ArrayList<String> htmlListL;
	
	public GetHtml2012300070048() {
		
		htmlListL = new ArrayList<String>();
		teacherIdL = new ArrayList<Integer>();
		
//		String teacherListUrlL = "http://wbm.whu.edu.cn/%e4%b8%93%e4%bb%bb%e6%95%99%e5%b8%88";
//		Document doc = null;
//		try {
//			doc = Jsoup.connect(teacherListUrlL).get();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} 
		String filePath = "D:/sa.html";
		File aaa = new File(filePath);
		Document doc = null;
		try {
			doc = Jsoup.parse(aaa,"utf-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Elements element = doc.select("a[href]");
		Pattern pattern = Pattern.compile("[0-9]{3,4}+\\.html");
		for (Element ele : element) {
			String s = ele.attr("href");
			Matcher match = pattern.matcher(s);
			if (match.find()) {
				int idx = getIdL(s);
				if (!isRepeatedL(idx)) {
					teacherIdL.add(idx);
					htmlListL.add(s);
				}
			}
		}
	}
	private int getIdL(String s) {
		int startIdx = s.lastIndexOf("/") + 1;
		int endIdx = s.lastIndexOf(".");
		s = s.substring(startIdx, endIdx);
		return Integer.parseInt(s);
	}
	
	private boolean isRepeatedL(int id) {
		for (int i = 0; i < teacherIdL.size(); i++) {
			if (id ==  teacherIdL.get(i))
				return true;
		}
		return false;
	}
	
	public int getSizeL() {
		return teacherIdL.size();
	}
	
	public ArrayList<String> getHtmlListL() {
		return htmlListL;
	}
	
	public ArrayList<Integer> getIdListL() {
		return teacherIdL;
	}
	
	public String getHtmlL(int i) {
		return htmlListL.get(i);
	}
	
}
