package com.wangle.spider;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 网页工厂类，生成Page对象,单例
 * @author wangle
 * @date 2015.11.02
 */
public class PageFactory {
	//单例模式，防止多线程运行时多次实例化，确保只有一个实例
	private volatile static PageFactory pageFactory;

	//获取所有老师的主页url的起始网页
	private static final String HOME_PAGE="http://cs.whu.edu.cn/plus/list.php?tid=36";

	private static int time;		//可以获取Page对象的次数，即list的size
	private static int index;		//索引
	private List<RawPage> list;		//url列表

	/**
	 * 私有构造函数，单例模式必备
	 */
	private PageFactory(){
		list=new ArrayList<RawPage>();
		try {
			Document doc=Jsoup.connect(HOME_PAGE).timeout(5000).get();
			//Document doc=Jsoup.parse(new File("page.html"), "utf-8");
			//选择所有的<dd>
			Elements elements=doc.select("dd.j_name");
			for(Element e:elements){
				//每个<dd>下有4个<span>，第一个是姓名（含主页链接），姓名为空的是无效链接（不知道怎么设计的……）
				Element node=e.child(0);
				//如果姓名不为空则是有效的链接
				if(!node.text().equals("")){
					String url="http://cs.whu.edu.cn/plus/"+node.child(0).attr("href");
					String name=node.text();
					String position=(e.child(1).text().equals(""))?"无":e.child(1).text();
					String sex=(e.child(2).text().equals(""))?"无":e.child(2).text();
					String searchArea=(e.child(3).text().equals(""))?"无":e.child(3).text();
					list.add(new RawPage(url,name,sex,position,searchArea));
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		index=0;
		time=list.size();
	}
	/**
	 * 获取工厂类实例
	 * @return 单例工厂类
	 */
	public static PageFactory newInstance(){
		if (pageFactory == null) {
			synchronized (PageFactory.class) {
				if (pageFactory == null) {
					pageFactory = new PageFactory();
				}
			}
		}
		if(index==time){
			index=0;
		}
		return pageFactory;
	}


	/**
	 * 获取page对象
	 * @return page
	 */
	public Page getPage(){
		RawPage rawPage=getRawPage();
		if(rawPage!=null){
			return new Page(rawPage);
		}
		else{
			return null;
		}
	}

	private RawPage getRawPage(){
		if(index<time){
			RawPage temp=list.get(index);
			index++;
			return temp;
		}
		else{
			return null;
		}
	}
	/**
	 * 获取页面的总数，用于判断是否到达List尾部
	 * @return 页面总数
	 */
	public int getPageNum(){
		return time;
	}
	/**
	 * 获得当前索引值
	 * @return 索引值
	 */
	public int getIndex(){
		return index;
	}
	/**
	 * 重置，设置索引值为0
	 */
	public void reset(){
		index=0;
	}
}


