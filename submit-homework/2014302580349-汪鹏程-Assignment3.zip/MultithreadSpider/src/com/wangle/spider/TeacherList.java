package com.wangle.spider;


import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.util.Enumeration;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

/**
 * JTable显示信息
 * @author wangle
 * @date 2015.11.05
 */
public class TeacherList extends JFrame {

	private static final long serialVersionUID = 1L;

	private List<Teacher> list;

	public TeacherList(){
		this.setTitle("教师列表");
		setForeground(new Color(153, 204, 255));
		setBackground(new Color(153, 204, 255));
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int)screensize.getWidth();
		int height = (int)screensize.getHeight();
		setBounds((int)(width*0.1), (int)(height*0.1), (int)(width*0.8), (int)(height*0.8));

		Container container = this.getContentPane();
		
		list=(new TeacherDao()).getAll();
		
		String[] headers = {"姓名","性别","职位","研究领域","邮箱","电话","简介"};
		String[][] data=new String[list.size()][7];
		for(int i=0;i<list.size();i++){
			Teacher teacher=list.get(i);
			data[i][0]=teacher.getName();
			data[i][1]=teacher.getSex();
			data[i][2]=teacher.getPosition();
			data[i][3]=teacher.getSearchArea();
			data[i][4]=teacher.getEmail();
			data[i][5]=teacher.getPhone();
			data[i][6]=teacher.getIntroduction();
		}
		JTable table = new JTable(data,headers);
		table.setRowHeight(28);
		table.setFont(new Font("宋体", Font.PLAIN, 18));
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setGridColor(new Color(80, 180, 255));
		table.getTableHeader().setReorderingAllowed(false);
		table.getTableHeader().setResizingAllowed(false);
		table.getTableHeader().setFont(new Font("宋体", Font.BOLD, 20));
		table.getTableHeader().setBackground(new Color(33, 147, 229));
		table.getTableHeader().setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
		//this.FitTableColumns(table);
		this.setRowProp(table);
		JScrollPane jsp = new JScrollPane(table);
		container.add(jsp);
		this.setVisible(true);
	}
	public void FitTableColumns(JTable table) {
		JTableHeader header = table.getTableHeader();
		int rowCount = table.getRowCount();
		Enumeration<TableColumn> columns = table.getColumnModel().getColumns();
		while (columns.hasMoreElements()) {
			TableColumn column = (TableColumn) columns.nextElement();
			int col = header.getColumnModel().getColumnIndex(
					column.getIdentifier());
			int width = (int) table.getTableHeader().getDefaultRenderer()
					.getTableCellRendererComponent(table,
							column.getIdentifier(), false, false, -1, col)
							.getPreferredSize().getWidth();
			for (int row = 0; row < rowCount; row++) {
				int preferedWidth = (int) table.getCellRenderer(row, col)
						.getTableCellRendererComponent(table,
								table.getValueAt(row, col), false, false,
								row, col).getPreferredSize().getWidth();
				width = Math.max(width, preferedWidth);
			}
			header.setResizingColumn(column);
			column.setWidth(width + table.getIntercellSpacing().width);
		}
	}
	public void setRowProp(JTable table) {  
		try {
			DefaultTableCellRenderer tcr = new DefaultTableCellRenderer() {  

				private static final long serialVersionUID = 1L;

				public Component getTableCellRendererComponent(JTable table,
						Object value, boolean isSelected, boolean hasFocus,
						int row, int column) {
					if (row % 2 == 0) {
						setBackground(Color.white);
					} else if (row % 2 == 1) {  
						setBackground(new Color(206, 231, 255));
					}
					return super.getTableCellRendererComponent(table, value,  
							isSelected, hasFocus, row, column);  
				}
			};

			tcr.setHorizontalAlignment(JLabel.CENTER);
			for (int i = 0; i < table.getColumnCount(); i++) {  
				table.getColumn(table.getColumnName(i)).setCellRenderer(tcr);  
			}  
		} catch (Exception ex) {  
			ex.printStackTrace();  
		}  

	}
}
