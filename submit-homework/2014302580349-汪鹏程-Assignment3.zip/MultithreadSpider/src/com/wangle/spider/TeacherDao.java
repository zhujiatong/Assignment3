package com.wangle.spider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 * 数据库操作，sqlite对写入、修改的并发支持不怎么好，容易造成数据库锁住，所以
 * 所有与数据库写入、修改有关的操作都是同步的
 * @author wangle
 * @date 2015.11.01
 */
public class TeacherDao implements BaseDao {
	private Connection con;
	private PreparedStatement pst;
	private Statement sta;
	/**
	 * 连接数据库
	 */
	private void connectDB(){
		try {
			Class.forName("org.sqlite.JDBC");
			con=DriverManager.getConnection("jdbc:sqlite:teacher.db");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 关闭连接
	 */
	private void closeDB(){
		try {
			if(pst!=null){
				pst.close();
				pst=null;
			}
			if(sta!=null&&!sta.isClosed()){
				sta.close();
				sta=null;
			}
			if(con!=null&&!con.isClosed()){
				con.close();
				con=null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取所有的教师信息
	 * @return 教师信息列表
	 */
	public List<Teacher> getAll(){
		String sql="SELECT * FROM teacher";
		List<Teacher> list=new LinkedList<Teacher>();
		this.connectDB();
		try {
			sta=con.createStatement();
			ResultSet rs=sta.executeQuery(sql);
			while(rs.next()){
				String name=rs.getString("name");
				String sex=rs.getString("sex");
				String searchArea=rs.getString("searchArea");
				String introduction=rs.getString("introduction");
				String email=rs.getString("email");
				String phone=rs.getString("phone");
				String position=rs.getString("position");
				list.add(new Teacher(name,sex,searchArea,introduction,email,phone,position));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.closeDB();
		return list;
	}
	/**
	 * 通过教师姓名查询,同名只返回第一个
	 * @param name 姓名
	 * @return 教师信息
	 */
	public Teacher getByName(String nm){
		String sql="SELECT * FROM teacher WHERE name=\""+nm+"\"";
		Teacher teacher=null;
		this.connectDB();
		try {
			sta=con.createStatement();
			ResultSet rs=sta.executeQuery(sql);
			if(rs.next()){
				String name=rs.getString("name");
				String sex=rs.getString("sex");
				String searchArea=rs.getString("searchArea");
				String introduction=rs.getString("introduction");
				String email=rs.getString("email");
				String phone=rs.getString("phone");
				String position=rs.getString("position");
				teacher=new Teacher(name,sex,searchArea,introduction,email,phone,position);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.closeDB();
		return teacher;
	}
	/**
	 * 单个写入数据库
	 * @param teacher 教师信息
	 */
	public synchronized void insert(Teacher teacher){
		String sql="INSERT INTO teacher(name,sex,searchArea,introduction,email,phone,position)"
				+ " values(?,?,?,?,?,?,?)";
		this.connectDB();
		try {
			pst=con.prepareStatement(sql);
			pst.setString(1, teacher.getName());
			pst.setString(2, teacher.getSex());
			pst.setString(3, teacher.getSearchArea());
			pst.setString(4, teacher.getIntroduction());
			pst.setString(5, teacher.getEmail());
			pst.setString(6, teacher.getPhone());
			pst.setString(7, teacher.getPosition());
			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.closeDB();
	}
	/**
	 * 同时写入多个
	 * @param teacherList 教师信息列表
	 */
	public synchronized void insert(List<Teacher> teacherList){
		for(Teacher t:teacherList){
			this.insert(t);
		}
	}

	/**
	 * 清空整个表
	 */
	public synchronized void  deleteAll(){
		String sql="DELETE FROM teacher";
		this.connectDB();
		try {
			sta=con.createStatement();
			sta.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.closeDB();
	}
	
	public int count(){
		String sql="SELECT count(*) FROM teacher";
		int num=0;
		this.connectDB();
		try {
			sta=con.createStatement();
			ResultSet rs=sta.executeQuery(sql);
			//结果集只有一行
			if(rs.next()){
				num=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.closeDB();
		return num;
	}

	//测试代码
	/*
	@Test
	public void test(){
		TeacherDao db=new TeacherDao();
		//System.out.println(db.getByName("wangle"));
		Teacher t=new Teacher("汪鹏程","男","IT","帅哥","不告诉你","不告诉你","不告诉你");
		db.insert(t);

		List<Teacher> list=db.getAll();
		for(Teacher tt:list){
			System.out.println(tt);
		}

		System.out.println(db.count());
		db.deleteAll();
	}
	*/
}


