package com.wangle.spider;


/**
 * 因为有些老师的研究领域和简介是混乱的，但在首页有表格显示研究领域
 * 所以这个类用来存储首页上各个老师的主页的url、姓名、性别、职位、研究领域
 * @author wangle
 * @date 2015.11.02
 */
public class RawPage {
	private String homepage;			//主页url
	private String name;				//姓名
	private String sex;					//性别
	private String position;			//职位
	private String searchArea;			//研究领域

	public RawPage(String homepage,String name,String sex,String position,String searchArea){
		this.homepage=homepage;
		this.name=name;
		this.sex=sex;
		this.position=position;
		this.searchArea=searchArea;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	public String getSearchArea() {
		return searchArea;
	}

	public void setSearchArea(String searchArea) {
		this.searchArea = searchArea;
	}


}
