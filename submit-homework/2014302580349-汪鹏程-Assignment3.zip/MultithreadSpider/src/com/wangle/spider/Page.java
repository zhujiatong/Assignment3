package com.wangle.spider;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

/**
 * 代表老师的主页，可获取所需的信息
 * @author wangle
 * @date 2015.11.02
 */
public class Page {
	private Document doc;
	private RawPage rawPage;
	public Page(RawPage rawPage){
		this.rawPage=rawPage;
		this.initDocument(rawPage.getHomepage());
	}
	private void initDocument(String url){
		try {
			doc=Jsoup.connect(url).timeout(5000).get();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取姓名
	 * @return name
	 */
	public String getName(){
		return rawPage.getName();
	}
	/**
	 * 获取性别
	 * @return sex
	 */
	public String getSex(){
		return rawPage.getSex();
	}
	/**
	 * 获取职位
	 * @return position
	 */
	public String getPosition(){
		return rawPage.getPosition();
	}
	/**
	 * 获取研究方向
	 * @return searchArea
	 */
	public String getSearchArea(){
		return rawPage.getSearchArea();
	}
	/**
	 * 获取简介
	 * @return introduction
	 */
	public String getIntroduction(){
		Elements e=doc.select("div.info_list");
		if(!e.text().equals("")){
			return e.text().trim();
		}
		return "无";
	}
	/**
	 * 获取邮件
	 * @return Email
	 */
	public String getEmail(){
		Elements e=doc.select("ul.about_info>li:nth-child(8)");
		String s=e.text();
		Pattern pattern=Pattern.compile("\\w+@(\\w+\\.)+\\w{2,}");
		Matcher m=pattern.matcher(s);
		if(m.find()){
			return m.group();
		}
		else{
			return "无";
		}
	}
	/**
	 * 获取电话
	 * @return phone
	 */
	public String getPhone(){
		Elements e=doc.select("ul.about_info>li:nth-child(6)");
		String s=e.text();
		Pattern pattern=Pattern.compile("\\d{11}|\\d{3}-\\d{8}|\\d{8}");
		Matcher m=pattern.matcher(s);
		if(m.find()){
			return m.group();
		}
		else{
			return "无";
		}
	}
}
