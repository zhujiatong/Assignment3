package com.wangle.spider;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 爬虫
 * @author wangle
 * @date 2015.11.04
 */
public class Spider {
	/**
	 * 单线程
	 */
	public static void SingleThread(){
		PageFactory fac=PageFactory.newInstance();
		TeacherDao dao=new TeacherDao();
		Page page=null;
		do{
			page=fac.getPage();
			if(page!=null){
				String name=page.getName();
				String sex=page.getSex();
				String searchArea=page.getSearchArea();
				String introduction=page.getIntroduction();
				String email=page.getEmail();
				String phone=page.getPhone();
				String position=page.getPosition();
				dao.insert(new Teacher(name,sex,searchArea,introduction,email,phone,position));
			}
		}while(page!=null);
	}
	/**
	 * 多线程
	 */
	public static void  MultiThread(){
		PageFactory fac=PageFactory.newInstance();
		TeacherDao dao=new TeacherDao();

		//线程数
		int threadNum=8;
		ExecutorService exe=Executors.newCachedThreadPool();
		for(int i=0;i<threadNum;i++){
			exe.execute(new Runnable(){
				@Override
				public void run() {
					Page page=null;
					do{
						page=fac.getPage();
						if(page!=null){
							String name=page.getName();
							String sex=page.getSex();
							String searchArea=page.getSearchArea();
							String introduction=page.getIntroduction();
							String email=page.getEmail();
							String phone=page.getPhone();
							String position=page.getPosition();
							dao.insert(new Teacher(name,sex,searchArea,introduction,email,phone,position));
						}
					}while(page!=null);
				}
			});
		}
		exe.shutdown();
	}
}
