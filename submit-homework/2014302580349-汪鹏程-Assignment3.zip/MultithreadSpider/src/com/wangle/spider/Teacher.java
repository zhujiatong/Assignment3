package com.wangle.spider;

/**
 * 教师entity类，与数据库中的每一行对应
 * @author wangle
 * @date 2015.11.01
 */
public class Teacher {

	private String name;                    //姓名
	private String sex;						//性别
	private String searchArea;           //研究领域
	private String introduction;         //简介
	private String email;                    //邮箱
	private String phone;                  //电话
	private String position;					//职位

	public Teacher(){}
	public Teacher(String name,String sex,String searchArea,String introduction,String email,String phone,String position){
		this.name=name;
		this.sex=sex;
		this.searchArea=searchArea;
		this.introduction=introduction;
		this.email=email;
		this.phone=phone;
		this.position=position;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSearchArea() {
		return searchArea;
	}

	public void setSearchArea(String searchArea) {
		this.searchArea = searchArea;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}

	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String toString(){
		return "姓名："+this.name+"\r\n"+
				"性别："+this.sex+"\r\n"+
				"职位："+this.position+"\r\n"+
				"研究领域："+this.searchArea+"\r\n"+
				"电话："+this.phone+"\r\n"+
				"email："+this.email+"\r\n"+
				"简介："+this.introduction;
	}
}
