package com.wangle.spider;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
/**
 * 进度条，两个线程，一个爬取，一个显示进度
 * @author wangle
 * @date 2015.11.05
 */
public class ProgressBarDialog extends JDialog {

	private static final long serialVersionUID = 1L;

	//爬取模式
	public static final int SINGLE_THREAD=0;
	public static final int MULTI_THREAD=1;

	//显示进度信息
	private JLabel message;
	//进度条
	private JProgressBar bar;
	private PageFactory fac;
	public ProgressBarDialog(int mode){
		setTitle("爬取进度");
		setModal(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		this.setForeground(Color.white);
		//居中显示并根据屏幕大小显示大小
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
		int width=(int) screen.getWidth();
		int height=(int) screen.getHeight();
		setBounds(width/3, height*9/20, width/3, height/10);

		JPanel panel=new JPanel();
		this.setContentPane(panel);
		
		fac=PageFactory.newInstance();
		//进度显示
		message=new JLabel(fac.getIndex()+"/"+fac.getPageNum());
		message.setFont(new Font("宋体", Font.PLAIN, 20));
		panel.add(message);
		//进度条
		bar=new JProgressBar();
		bar.setOrientation(JProgressBar.HORIZONTAL);
		bar.setMinimum(0);
		bar.setMaximum(fac.getPageNum());
		bar.setValue(0);
		bar.setPreferredSize(new Dimension(width/3, height/32));
		bar.setBorderPainted(false);
		bar.setBackground(new Color(240,240,240));
		bar.setForeground(new Color(33, 147, 239));
		panel.add(bar);
		
		//进程
		ExecutorService exe=Executors.newCachedThreadPool();
		//进度条进程，首先重置索引
		fac.reset();
		exe.execute(new BarThread());
		//爬取进程
		exe.execute(new Runnable(){
			@Override
			public void run() {
				switch(mode){
				case SINGLE_THREAD:
					Spider.SingleThread();
					break;
				case MULTI_THREAD:
					Spider.MultiThread();
					break;
				default:
					break;
				}
			}
		});
		exe.shutdown();
		setVisible(true);
	}
	/**
	 * 进度条进程
	 * @author wangle
	 * @date 2015.11.05
	 */
	class BarThread implements Runnable{
		@Override
		public void run() {
			long time1=System.currentTimeMillis();
			while(fac.getIndex()<fac.getPageNum()){
				//设置值为当前索引值
				bar.setValue(fac.getIndex());
				message.setText("已爬取"+fac.getIndex()+"个，共"+fac.getPageNum()+"个");
				try {
					TimeUnit.MILLISECONDS.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			long time2=System.currentTimeMillis();
			bar.setValue(fac.getPageNum());
			message.setText("爬取完成，用时："+(time2-time1)+"ms");
		}
		
	}
}
