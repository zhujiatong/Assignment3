package com.wangle.spider;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
/**
 * 
 * @author wangle
 * @date 2015.11.05
 */
public class MainGUI2014302580349 extends JFrame {
	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	public static void main(String[] args) {
		MainGUI2014302580349 frame = new MainGUI2014302580349();
		frame.setVisible(true);
	}
	
	public MainGUI2014302580349() {
		setTitle("武汉大学计算机学院教师信息");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		//居中显示并根据屏幕大小显示大小
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
		int width=(int) screen.getWidth();
		int height=(int) screen.getHeight();
		setBounds(width/4, height/4, width/2, height/2);
		
		contentPane = new JPanel();
		//网格布局，划分为四个部分
		contentPane.setLayout(new GridLayout(2,2));
		setContentPane(contentPane);

		JButton singleThread=new JButton("单线程");
		singleThread.setFont(new Font("宋体", Font.PLAIN, 32));
		singleThread.setBackground(new Color(30, 144, 255));
		singleThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
		singleThread.addMouseListener(new MouseListener(){
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new ProgressBarDialog(ProgressBarDialog.SINGLE_THREAD);
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				singleThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				singleThread.setBackground(new Color(60, 164, 255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				singleThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				singleThread.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mousePressed(MouseEvent arg0) {
				singleThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				singleThread.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mouseReleased(MouseEvent arg0) {
				singleThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				singleThread.setBackground(new Color(30, 144, 255));
			}
		});
		contentPane.add(singleThread);


		JButton multiThread=new JButton("多线程");
		multiThread.setFont(new Font("宋体", Font.PLAIN, 32));
		multiThread.setBackground(new Color(30, 144, 255));
		multiThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
		multiThread.addMouseListener(new MouseListener(){
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new ProgressBarDialog(ProgressBarDialog.MULTI_THREAD);
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				multiThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				multiThread.setBackground(new Color(60, 164, 255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				multiThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				multiThread.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mousePressed(MouseEvent arg0) {
				multiThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				multiThread.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mouseReleased(MouseEvent arg0) {
				multiThread.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				multiThread.setBackground(new Color(30, 144, 255));
			}
		});
		contentPane.add(multiThread);

		JButton clear=new JButton("清空");
		clear.setFont(new Font("宋体", Font.PLAIN, 32));
		clear.setBackground(new Color(30, 144, 255));
		clear.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
		clear.addMouseListener(new MouseListener(){
			@Override
			public void mouseClicked(MouseEvent arg0) {
				TeacherDao dao=new TeacherDao();
				int num=dao.count();
				dao.deleteAll();
				JOptionPane.showConfirmDialog(null,"数据库已清空，共删除"+num+"条数据",
						"确定", JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE);
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				clear.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				clear.setBackground(new Color(60, 164, 255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				clear.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				clear.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mousePressed(MouseEvent arg0) {
				clear.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				clear.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mouseReleased(MouseEvent arg0) {
				clear.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				clear.setBackground(new Color(30, 144, 255));
			}
		});
		contentPane.add(clear);

		JButton show=new JButton("查看");
		show.setFont(new Font("宋体", Font.PLAIN, 32));
		show.setBackground(new Color(30, 144, 255));
		show.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
		show.addMouseListener(new MouseListener(){
			@Override
			public void mouseClicked(MouseEvent arg0) {
				new TeacherList();
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				show.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				show.setBackground(new Color(60, 164, 255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				show.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				show.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mousePressed(MouseEvent arg0) {
				show.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				show.setBackground(new Color(30, 144, 255));
			}
			@Override
			public void mouseReleased(MouseEvent arg0) {
				show.setBorder(BorderFactory.createLineBorder(new Color(33, 147, 239)));
				show.setBackground(new Color(30, 144, 255));
			}
		});
		contentPane.add(show);
	}

}
