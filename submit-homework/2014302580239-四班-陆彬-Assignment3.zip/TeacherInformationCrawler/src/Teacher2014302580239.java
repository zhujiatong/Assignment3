
public class Teacher2014302580239 {
	
	public String Url;
	public String Name;
	public String Title;
	public String ResearchDirection;
	public String Phone;
	public String Email;
	
	public Teacher2014302580239()
	{
		
	}

}
