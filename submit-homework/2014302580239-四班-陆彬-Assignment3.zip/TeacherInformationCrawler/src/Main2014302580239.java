import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main2014302580239 {

	public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
          Crawler2014302580239 crawler=new Crawler2014302580239();
          
          System.out.println("���߳��������ڽ��У����Ե�...");
          long StartTime1=System.currentTimeMillis();
          crawler.singleCraw("http://staff.whu.edu.cn");
          long EndTime1=System.currentTimeMillis();
          System.out.println("���߳�������ɣ�����ʱ��Ϊ:"+(EndTime1-StartTime1)+"ms\n");
                    
          System.out.println("���߳��������ڽ��У����Ե�...");
          long StartTime2=System.currentTimeMillis();
          crawler.MutiCrawl("http://staff.whu.edu.cn");
          long EndTime2=System.currentTimeMillis();
          System.out.println("���߳�������ɣ�����ʱ��Ϊ:"+(EndTime2-StartTime2)+"ms");
          
          
          //build a table and send the data to table
          Database2014302580239 database=new Database2014302580239();
          database.conn=database.getConnection("root", "lubin1995");
          String tablename="TeachersList";
          database.buildTable(database.conn,tablename);
          for(int i=0;i<crawler.teacherlist_muti.getNumOfTeacher();i++)
        	  database.setData(crawler.teacherlist_muti.teachers[i],tablename);
          database.stmt.close();
          database.conn.close();
	}
	

}
