import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class TeacherList2014302580239 {
      
	Teacher2014302580239 [] teachers=new Teacher2014302580239[100];
	
	private int NumOfTeachers=0;
	
	public int getNumOfTeacher()
	{
		return NumOfTeachers;
	}
	
	public void getUrls(String url) throws IOException
	{

		HttpRequest response=new HttpRequest(url,"GET");
		File input=new File("files/input.html");
		response.receive(input);
		Document doc=Jsoup.parse(input,"UTF-8");
		Elements elements=doc.select("div.details > p > a[href]");
	    for(Element node:elements)
		{
			teachers[NumOfTeachers]=new Teacher2014302580239();
			teachers[NumOfTeachers].Url=url+"/"+node.attr("href");
			NumOfTeachers++;
	    }
	}
	
	public void getInformation(int index) throws IOException
	{
		Document doc=Jsoup.connect(teachers[index].Url).get();
		Element name=doc.select("h3[class=title]").first();
		teachers[index].Name=name.text();
		
		Element div = doc.select("div[class=details col-md-10 col-sm-9 col-xs-7]").first();
		Element p=div.select("p").first();
		String s=p.html();
		String [] str=s.split("<br>");
		teachers[index].Title=str[0];
		String [] str3=str[1].split("<");
		teachers[index].ResearchDirection=str3[0];
		
		String str1="1[0-9]{10}";
		Pattern p1=Pattern.compile(str1);
		Matcher m=p1.matcher(doc.text());
		String str4="(\\d{3,4}-)\\d{7,8}";
		Pattern p4=Pattern.compile(str4);
		Matcher m4=p4.matcher(doc.text());
		String Tel="";
		while(m.find())
		{
		    Tel=m.group();			
		}
		while(m4.find())
		{
		    Tel=m4.group();			
		}
        teachers[index].Phone=Tel;
        
        String str2="\\w+@\\w+(\\.\\w{2,3})*\\.\\w{2,3}";
		Pattern p2=Pattern.compile(str2);
		Matcher m2=p2.matcher(doc.text());
		String Email="";
		while(m2.find())
		{
			Email=m2.group();			
		}
		teachers[index].Email=Email;
	}
	
	
}
