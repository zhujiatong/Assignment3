import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;





public class Database2014302580239 {
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost/new_schema";

    Connection conn = null;
	Statement stmt = null;
	   
	public Connection getConnection(String user,String password) throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
	    conn = DriverManager.getConnection(DB_URL,user,password);
        return conn;
	}
	
	public void buildTable(Connection conn,String TableName) throws SQLException
	{
		stmt = conn.createStatement();
		String sql = "create table "+TableName+"("
				+ "id int unsigned not null auto_increment primary key,"
				+ "Name char(8) not null,"
	      		+ "Title char(20) not null,"
	      		+ "ResearchDirection char(50) not null,"
	      		+ "Phone char(50) not null,"
	      		+ "Email char(50)"
	      		+ ");";
	      stmt.execute(sql);
	}
	
	public void setData(Teacher2014302580239 teacher,String TableName) throws SQLException
	{
		String sql="insert into "+TableName+"(ID,Name,Title,ResearchDirection,Phone,Email) "
					+ "values("+"NULL,\""+teacher.Name+"\",\""+teacher.Title+"\",\""+teacher.ResearchDirection
					+"\",\""+teacher.Phone+"\",\""+teacher.Email+"\");";
		stmt.execute(sql);
	}
}


