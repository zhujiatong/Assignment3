import java.io.File;
import java.io.IOException;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

public class Crawler2014302580239 {
	
	public TeacherList2014302580239 teacherlist_single= new TeacherList2014302580239();
	public TeacherList2014302580239 teacherlist_muti=new TeacherList2014302580239();	
	
	public void singleCraw(String url) throws IOException
	{
		teacherlist_single.getUrls(url);
		for(int i=0;i<teacherlist_single.getNumOfTeacher();i++)
		  teacherlist_single.getInformation(i);
	}
	
	public class MutiCrawler implements Runnable
	{
		private int num;
		public MutiCrawler(int i)
		{
			this.num=i;
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
		for(int i=0;i<50;i++)
		{
			try {
				teacherlist_muti.getInformation(i+10*num);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    }
		}
	}
	
	public void MutiCrawl(String url) throws IOException, InterruptedException
	{
		teacherlist_muti.getUrls(url);
		MutiCrawler muticrawler0=new MutiCrawler(0);
		Thread thread=new Thread(muticrawler0);
		thread.start();
		MutiCrawler muticrawler1=new MutiCrawler(1);
		Thread thread1=new Thread(muticrawler1);
		thread1.start();
	}

}


