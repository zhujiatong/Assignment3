import java.io.IOException;

public class main2014302580176 {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		Parse2014302580176 parserOne = new Parse2014302580176();
		parserOne.parseUrl();
		SinThread2014302580176 sin = new SinThread2014302580176();
		sin.entrance();
		//sin.TranData();
		//ParThread2014302580176 par = new ParThread2014302580176();
		//par.entrance();
	}

}
