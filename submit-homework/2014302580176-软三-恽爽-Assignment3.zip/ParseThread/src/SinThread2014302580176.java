
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

import com.mysql.jdbc.PreparedStatement;

public class SinThread2014302580176 implements Runnable{

	private static int processing_count = 0;
	
	
	//synchronized get
	public static synchronized int getCount(){
		return processing_count++;
	}
	
	
	//��ʼ����
	public void entrance(){
		Thread thread = new Thread(new SinThread2014302580176());
		thread.start();
	}
	
	
	//���ص�run����
	public void run(){
		
		long beginTime = System.currentTimeMillis();			//��ʼʱ��
		
		String[] urls = Parse2014302580176.parthref;			//���������Ҫ��ȡ��url
		int current_count = getCount();									//�ƽ�ʦ�ĸ���

		try{
			Class.forName("com.mysql.jdbc.Driver"); 
	        String url="jdbc:mysql://localhost:3306/myfirstdb?user=root&password=AlwaYs$12138";
	        java.sql.Connection con = DriverManager.getConnection(url);
			
			while(current_count<50){
				
					PreparedStatement sttm = (PreparedStatement)con
							.prepareStatement("insert into table1(col1,col2,col3,col4,table1col,table1col1,table1col2,table1col3)values(?,?,?,?,?,?,?,?)");
					
					Elements eles = Jsoup.connect(urls[current_count]).timeout(10000).get().getElementsByTag("li");//ÿ���˵�url
					
					current_count = getCount();					//current_count����
					
					for(int j= 0,count = 0;j<eles.size();j++){
						
						String processing = eles.get(j).toString().split("<|>")[2];		//��ÿ��<li>����ȡ�ڶ���
						
						if(count < 8 && processing.length()>2){				//ֻҪǰ���������ֳ��ȴ���2����Ϣ��
							
							sttm.setString(count+1, processing);			//Ҫ+1��MySQL��1��ʼ
							count++;
						}
					}
					
				    sttm.executeUpdate();
				    sttm.close();
				    
			}
			
	        con.close();
	        
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print(Thread.currentThread().getName() + ":" +(System.currentTimeMillis()-beginTime));
	}
	
	/*public void TranData(){
		 
		try{ 
		//����MySql�������� 
			Class.forName("com.mysql.jdbc.Driver"); 
	        String url="jdbc:mysql://localhost:3306/myfirstdb?user=root&password=AlwaYs$12138";
	        java.sql.Connection con = DriverManager.getConnection(url);
			PreparedStatement sttm = (PreparedStatement)con.prepareStatement("insert into table1(col1,col2,col3,col4)values(?,?,?,?)");
	        sttm.setString(1,"aaa");
	        sttm.setString(2,"bbb");
	        sttm.setString(3,"ccc");
	        sttm.setString(4,"ddd");
	        sttm.executeUpdate();
	        sttm.close();
	        con.close();
	        
		}catch(ClassNotFoundException e){
			System.out.println("�Ҳ������������� ����������ʧ�ܣ�"); 
			e.printStackTrace(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		  
	}*/
}
