import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class ParThread2014302580176 implements Runnable{
	private static int processing_count = 0;
	
	public static synchronized int getCount(){
		return processing_count;
	}
	
	public static synchronized void setCount(int t){
		processing_count = t;
	}
	
	public void entrance(){
		Thread threadOne = new Thread(new SinThread2014302580176());
		threadOne.start();
		try {
			Thread.currentThread();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread threadTwo = new Thread(new SinThread2014302580176());
		threadTwo.start();
		try {
			Thread.currentThread();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread threadThree = new Thread(new SinThread2014302580176());
		threadThree.start();
		
	}
	public void run(){/*
		long beginTime = System.currentTimeMillis();
		long time = 0;
		Parse2014302580176 parser = new Parse2014302580176();
		String[] urls = Parse2014302580176.parthref;
		while(getCount()<50){
			try {
				Elements eles = Jsoup.connect(urls[getCount()]).timeout(10000).get().getElementsByTag("li");

				setCount(getCount()+1);
				
				int count = 0;
				for(int j= 0;j<eles.size();j++){
					String processing = eles.get(j).toString().split("<|>")[2];
					if(count < 8 && processing.length()>2){//ֻҪǰ���������ֳ��ȴ���2����Ϣ��
						System.out.println(processing);
						count++;
					}
				}
				System.out.println("********************"+processing_count);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(System.currentTimeMillis()-beginTime);*/
	}
}