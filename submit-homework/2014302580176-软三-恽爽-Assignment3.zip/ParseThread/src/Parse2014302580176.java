import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
public class Parse2014302580176 {
	public static String[] parthref = new String[100];
	
	public static void parseUrl(){
		File local = new File("local.html");
		Document one;
		try {
			one = Jsoup.parse(local, "UTF-8");
			Elements hrefs = one.getElementsByTag("dd");
			//System.out.println(hrefs.get(0).getElementsByTag("a").toString().split("<|>")[1].split("\"")[1]);
			for(int i = 0,j = 0; i < hrefs.size()-3; i++){
				String href = hrefs.get(i).getElementsByTag("a").toString();
				if(0!=href.split(">|<")[2].length()&&href.split("<|>")[2].length()<5){
					//System.out.println(href.split("<|>")[2]);
					//System.out.println(href);//.split("\"")[1]);
					
					//System.out.println(href.split("\"")[1]);
					parthref[j] = "http://cs.whu.edu.cn/plus/" + href.split("\"")[1];
					System.out.println(parthref[j]);
					j++;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void parseToLocal(){
		try{
			File local = new File("local.html");
			FileWriter wri = new FileWriter(local);
			wri.write(Jsoup.connect("http://cs.whu.edu.cn/plus/list.php?tid=36").get().toString());
			wri.close();
		}catch(IOException e){
			
		}
	}
}
