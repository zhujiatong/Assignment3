import java.io.IOException;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ReadURL2014302580035 {

	Queue<String> urlQueue = new PriorityQueue<>();		//教师主页链接
	Thread[] threads= new ReaderThread[10];				//爬取线程

	//爬取线程类
	class ReaderThread extends Thread{
		public void run(){
			try{
				String url;
				synchronized (urlQueue) {
					url = urlQueue.poll();
				}
				ReadTeacherInfo(url);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}

	//初始化爬取信息
	public ReadURL2014302580035() throws IOException{
		String url ="http://www.thss.tsinghua.edu.cn/publish/soft/3655/index.html";
		Document doc = Jsoup.connect(url).get();
		Element content = doc.getElementById("s2_right_con");
		Elements links = content.getElementsByTag("a");
		for (Element link : links){
			String linkHref = link.attr("href");
			if (urlQueue.contains("http://www.thss.tsinghua.edu.cn" + linkHref)){
				continue;
			}
			else{
				urlQueue.offer("http://www.thss.tsinghua.edu.cn" + linkHref);
			}
		}
		
	}

	//单线程爬取
	public void SingleThreadReadVector() throws IOException{
		long startTime = System.currentTimeMillis();
		while (!urlQueue.isEmpty()){
			String url= urlQueue.poll();
			ReadTeacherInfo(url);
		}
		System.out.println("单线程解析信息用时: " + (System.currentTimeMillis() - startTime));
	}

	//多线程爬取
	public void MultiThreadsReadVector() throws IOException{
		long startTime = System.currentTimeMillis();
	
		for(int i = 0; i < threads.length; ++i){
			threads[i] = new ReaderThread();
			threads[i].start();
		}
		
		while(!urlQueue.isEmpty()){
			for(int i = 0; i < threads.length; ++i){
				if(threads[i].getState() == Thread.State.TERMINATED){
					threads[i] = new ReaderThread();
					threads[i].start();
				}
			}
		}
		System.out.println("多线程解析信息用时: " + (System.currentTimeMillis() - startTime));
	}

	//读取信息
	public void ReadTeacherInfo(String url)throws IOException{
		Teacher2014302580035 teacher = new Teacher2014302580035();
		Document doc = Jsoup.connect(url).get();
		Element content = doc.getElementById("s2_right_con");

		String name = readName(content);
		if(name == null){
			return;
		}
		String phone = readPhone(content);
		String email = readEmail(content);
		String field = readField(content);
		String honor = readHonor(content);

		teacher.setName(name);
		teacher.setPhone(phone);
		teacher.setEmail(email);
		teacher.setField(field);
		teacher.setHonor(honor);
		try{
			teacher.writeToMySQL();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String readName(Element content) throws IOException{
		Elements content2 = content.getElementsByTag("p");
		String text;
		for(Element _content : content2){
			text = _content.text();
			if(text.contains("姓名")) {
				try {
					return text.substring(text.indexOf("："), text.indexOf(" "));
				} catch (StringIndexOutOfBoundsException e) {
					try {
						return text.substring(text.indexOf("："));
					}
					catch (StringIndexOutOfBoundsException el){
						return null;
					}
				}
			}
		}

		return null;
	}
	
	public String readPhone(Element content) throws IOException{
		Elements content2 = content.getElementsByTag("p");
		String text;
		for(Element _content : content2){
			text = _content.text();
			Pattern phone_pattern = Pattern.compile("(\\+)*[0-9]+(\\-[0-9]+)*");
			Matcher phone_matcher = phone_pattern.matcher(text);
			if(phone_matcher.find()){
				return phone_matcher.group();
			}
		}
		return null;
	}
	
	public String readEmail(Element content) throws IOException{
		Elements content2 = content.getElementsByTag("p");
		String text;
		for(Element _content : content2){
			text = _content.text();
			Pattern email_pattern = Pattern.compile("[a-zA-Z0-0]+@([a-zA-Z0-9].)*[a-zA-Z0-9]+");
			Matcher email_matcher = email_pattern.matcher(text);
			if(email_matcher.find()){
				return email_matcher.group();
			}
		}
		return null;
	}
	
	public String readField(Element content) throws IOException{
		for(Element _content : content.getElementsByTag("h4")){
			String text = _content.text();
		    if (text.contains("研究领域")){
		    	return _content.nextElementSibling().text();
		    }
		}
	    return null;
	}
	

	public String readHonor(Element content) throws IOException{
		for(Element _content : content.getElementsByTag("h4")){
			String text = _content.text();
		    if (text.contains("荣誉")){
		    	return _content.nextElementSibling().text();
		    }
		}
	    return null;
	}
}
