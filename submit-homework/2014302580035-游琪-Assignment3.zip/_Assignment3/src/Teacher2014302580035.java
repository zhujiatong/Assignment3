import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Teacher2014302580035 {
	String name;
	String phone;
	String email;
	String field;
	String honor;
	static Connection conn = null;

	public Teacher2014302580035(){

	}

	//初始化数据库
	public static void InitMysql(){
		String sql;
		int result;
		String url = "jdbc:mysql://localhost:3306/?useUnicode=true&characterEncoding=UTF-8";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, "root","");
			Statement stmt = conn.createStatement();
			sql = "create database if not exists teacherinformation;";
			result = stmt.executeUpdate(sql);
			sql = "use teacherinformation;";
			result = stmt.executeUpdate(sql);
			sql = "drop table if exists teacher;";
			result = stmt.executeUpdate(sql);
			sql = "create table teacher(name VARCHAR(20),phone VARCHAR(20),email VARCHAR(200),field VARCHAR(1000),honor VARCHAR(1000))DEFAULT CHARSET=utf8;";
			stmt.execute(sql);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void setName(String _name){
		name = _name;
	}
	
	public void setPhone( String _phone){
		phone = _phone;
	}
	
	
	public void setEmail(String _email){
		email = _email;
	}
	
	public void setField(String _field){
		if(_field == null){
			field = null;
			return;
		}
		field = _field.replace("\"", "\\\"");
	}
	
	public void setHonor(String _honor){
		honor = _honor;
	}

	//写入数据库
	public void writeToMySQL()throws SQLException{
		Statement stmt = conn.createStatement();
		String sql;
	    sql = "insert into teacher(name,phone,email,field,honor) values(\"" + name + "\",\"" + phone + "\",\"" + email + "\",\"" + field + "\",\"" + honor + "\");";
	    stmt.executeUpdate(sql);
	    sql = "select * from teacher";
	    ResultSet rs = stmt.executeQuery(sql);			
	} 
}
