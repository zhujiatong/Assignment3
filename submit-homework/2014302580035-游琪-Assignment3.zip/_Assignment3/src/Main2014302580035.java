import java.io.IOException;

public class Main2014302580035 {

	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
		Teacher2014302580035.InitMysql();						//初始化数据库
		ReadURL2014302580035 a = new ReadURL2014302580035();	//创建爬虫
		a.SingleThreadReadVector();								//使用单线程爬取
		System.out.println("----------------------------");
		Teacher2014302580035.InitMysql();						//初始化数据库
		ReadURL2014302580035 b = new ReadURL2014302580035();	//创建爬虫
		b.MultiThreadsReadVector();								//使用多线程爬取
	}
}
