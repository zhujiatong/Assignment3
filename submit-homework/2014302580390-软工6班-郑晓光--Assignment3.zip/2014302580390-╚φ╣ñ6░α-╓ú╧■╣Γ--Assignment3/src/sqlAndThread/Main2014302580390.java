package sqlAndThread;

public class Main2014302580390 {
	

	public static void main(String[] args){
		SingleThread2014302580390.main(args);
		MulitThread2014302580390.main(args);
		
	}
}
