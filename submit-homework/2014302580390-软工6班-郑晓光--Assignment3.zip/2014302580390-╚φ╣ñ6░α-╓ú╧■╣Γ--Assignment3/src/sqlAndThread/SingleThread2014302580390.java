package sqlAndThread;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SingleThread2014302580390 {	
	String url;
	Document doc;
	public Connection con;
	public Conn2014302580390 c=new Conn2014302580390();
	public void run(){
		
		try{
			
			int number[]=new int[]{157,66,68,150,191,173,724,67,130,131,124,158};
			for(int i=0;i<12;i++){
				PreparedStatement ps=null;
				con=c.getConnection();
				StringBuilder sb = new StringBuilder();
				url="http://physics.whu.edu.cn/old/node/"+String.valueOf(number[i]);
	            doc = Jsoup.connect(url).get(); 
			    Element content = doc.select("div.content").get(2);                        
		        Elements links = content.getElementsByTag("p");  
		        for(Element link:links){
		        	String linkText = link.text();
		        	sb.append(linkText);

		        	
		        }
		        
		        String sql="insert into profeeesion (content) values('"+sb+"');";
		        //ps=con.prepareStatement("delete from profeeesion");
			    ps=con.prepareStatement(sql);
			    ps.executeUpdate(sql);
		        //ps.executeUpdate("delete from profeeesion");
			    ps.close();
			    con.close();
			}
			
		   
		}catch(Exception e){
			e.printStackTrace();
		}
	
	}

	public static void main(String[] args) {
		long start2 = System.currentTimeMillis();
		new SingleThread2014302580390().run();
		long end2 = System.currentTimeMillis();
		System.out.println("The time SingleThread used:"+(end2-start2));

	}

}
