package sqlAndThread;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MulitThread2014302580390 extends Thread {
	private Lock lock;
	public  int i;
	public String url;
	public Document doc;
	public Connection con;
	public Conn2014302580390 c=new Conn2014302580390();
	
	
	public MulitThread2014302580390(int number){
		i=number;
		lock=new ReentrantLock();
	}
	public int number[]=new int[]{157,66,68,150,191,173,724,67,130,131,124,158};
	public void run(){
		
		
			
		
		
		try{
			PreparedStatement ps=null;
			url="http://physics.whu.edu.cn/old/node/"+String.valueOf(number[i]);
		    doc = Jsoup.connect(url).get(); 
			Element content = doc.select("div.content").get(2);                        
		    Elements links = content.getElementsByTag("p"); 
		    lock.lock();
		    con=c.getConnection();
		    StringBuilder sb = new StringBuilder();
		    for(Element link:links){
		        	String linkText = link.text();
		        	sb.append(linkText);	        	
		  
		    }
		    String sql="insert into profeeesion (content) values('"+sb+"');";
		    ps=con.prepareStatement(sql);
		    ps.executeUpdate(sql);
		    ps.close();
		    con.close();
			lock.unlock();
		}catch(Exception e){
			e.printStackTrace();
		}
		}
	public static void main(String[] args) {
		
		MulitThread2014302580390 m[]=new MulitThread2014302580390[19];
		long start1 = System.currentTimeMillis();
		for(int j=0;j<12;j++){
			m[j]=new MulitThread2014302580390(j);
			m[j].start();
		
	    }
	
		for(int j=0;j<12;j++){
			try {
				m[j].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			};
			
	    }
		
		long end1 = System.currentTimeMillis();
		System.out.println("The time MulitThread used:"+(end1-start1));


		
	}

}
