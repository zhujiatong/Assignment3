package assignment3;

public class Teacher2014302580017 {
	private String name;
	private String mail;
	private String phone;
	private String area;
	private String resume;
	public Teacher2014302580017(String name, String mail, String phone, String area, String resume) {
		super();
		this.name = name;
		this.mail = mail;
		this.phone = phone;
		this.area = area;
		this.resume = resume;
	}
	public String getName() {
		return name;
	}
	public String getMail() {
		return mail;
	}
	public String getPhone() {
		return phone;
	}
	public String getArea() {
		return area;
	}
	public String getResume() {
		return resume;
	}
	@Override
	public String toString() {
		return "Teacher [name=" + name + ", mail=" + mail + ", phone=" + phone + ", area=" + area + ", resume=" + resume
				+ "]";
	}
	
}
