package assignment3;

import java.sql.*;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

public class AccessDataBase2014302580017 {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/assignment3";

	// Database credentials
	static String USER;
	static String PASS;

	private Connection conn = null;
	private Statement stmt = null;

	public AccessDataBase2014302580017(String user, String pass) {
		USER = user;
		PASS = pass;
		init();
	}

	public void addData(Teacher2014302580017 teacher) {
		if (teacher != null) {
			try {
				String sql = "insert into teachers values("+"NULL,\""+teacher.getName()+"\",\""+teacher.getMail()+ "\",\""+teacher.getPhone()+"\",\""+teacher.getArea()+"\",\""+teacher.getResume()+"\");";
				stmt.execute(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void close(){
		
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	
	public static void clear(){
		try {
			String sql = "drop table teachers;";
			Statement stmt =  DriverManager.getConnection(DB_URL, USER, PASS).createStatement();
			stmt.execute(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void init() {

		try {
			// STEP 1: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// STEP 2: Open a connection
			//System.out.println("DataBase: Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// STEP 3: Execute a query
			//System.out.println("DataBase: Creating statement...");
			stmt = conn.createStatement();
			String sql;
			
			sql = "SET character_set_client = utf8;";
			stmt.execute(sql);
			
			sql = "SET character_set_results = utf8;";
			stmt.execute(sql);
			
			sql = "SET character_set_connection = utf8;";
			stmt.execute(sql);
			
			sql = "create table if not exists teachers(id int unsigned not null auto_increment primary key,name char(12) not null,mail char(30) not null,phone char(20) not null,area char(50) not null,resume varchar(5000) not null)   DEFAULT CHARSET=utf8;";
			stmt.execute(sql);

		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} 
		//System.out.println("DataBase: Goodbye!");

	}
}
