package assignment3;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Crawler2014302580017 {
	private URL url;
	
	public Teacher2014302580017 getTeacher(){
		try {
			 Document doc =  Jsoup.parse(url,5000);
			 Element detail = doc.getElementsByClass("teachersdetail").first();
			 
			 //����
			 String name = new String(detail.getElementsByClass("name").first().text().trim().getBytes("utf-8"),"utf-8");
			 
			 Elements li = detail.getElementsByTag("li");
			 
			 //�о�����
			 String[] temp = li.get(2).text().split("��");
			 String area = new String(temp[1].trim().getBytes("utf-8"),"utf-8");
			 
			 //�绰
			 temp = li.get(3).text().split("��");
			 String phone = new String(temp[1].trim().getBytes("utf-8"),"utf-8");
			 
			 //����	 
			 temp = li.get(4).text().split("��");
			 String mail = new String(temp[1].trim().getBytes("utf-8"),"utf-8");
			 
			 //���
			 Elements es = doc.getElementsByTag("div");
			 String resume = new String(doc.getElementsByAttributeValueMatching("class", "openlist togglecontent").text().getBytes("utf-8"),"utf-8");
			 
			 
			 Teacher2014302580017 teacher = new Teacher2014302580017(name, mail, phone, area, resume);
			 //System.out.println(teacher.toString());
			 return teacher;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ArrayIndexOutOfBoundsException e){
			return null;
		}
		return null;
		
	}
	
	public Crawler2014302580017(String url){
		try {
			this.url = new URL(url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
