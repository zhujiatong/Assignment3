package assignment3;


public class MyThread2014302580017 extends Thread {
	private String url;
	
	public MyThread2014302580017(){
		
	}
	
	public MyThread2014302580017(String url){
		this.url = url;
	}
	
	public void run() { 
		
		Teacher2014302580017 t = new Crawler2014302580017(url).getTeacher();
		

		AccessDataBase2014302580017 adb = new AccessDataBase2014302580017("root", "************");//������ô�ܸ�������
		adb.addData(t);
		adb.close();
	}
}
