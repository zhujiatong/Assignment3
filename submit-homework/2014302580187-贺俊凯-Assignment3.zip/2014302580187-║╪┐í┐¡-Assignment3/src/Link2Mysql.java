import java.io.File;
import java.sql.*;
import java.util.concurrent.ExecutorService;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
class Link2Mysql {
	static void link(String info[],Connection connection,Statement state) throws Exception
	{	
		int i=0;
		String str = "INSERT INTO assignment.teacher (Name,HomePage,Sex,Office,Bachelor,Phone,Place,Email,Teacher,ResearchDirection,Education,Experience,Lessons,Thesis,Issue,WorkGroup,Awards,Service) VALUES (";
		while(i<info.length-1)
		{
			//info[i].replace("\"", "'");
			str+="\""+info[i].replace("\"", "'")+"\""+",";
			i++;
		}
		//info[i].replace("\"", "'");
		str+="\""+info[info.length-1].replace("\"", "'")+"\")";
		//System.out.println(str);
		state.executeUpdate(str);
		}
}

class Link2MysqlThread implements Runnable{
	private File info[];
	private Connection connection;
	private Statement state;
	private int count;
	private ExecutorService exec;
	static void getTeacherInfo(String filePath,Connection connection,Statement statement) throws Exception
	{
		File file = new File(filePath);
		Document document = Jsoup.parse(file,"UTF-8");
		Elements elements = document.select("ul[class*=\"about_info fn_left\"] li,div[class*=\"info_list\"]");
		//System.out.println(elements.size());
		String[] info = new String[10];
		int i = 0;
		while(i<elements.size())
		{
		
			String tmp = elements.get(i).text().replace('\"','��');
			if(elements.get(i).text().equals(""))
				{
				info[i]="NULL";
				i++;
				continue;
				}		
			if(i+1==elements.size())
			{
				if(tmp.length()<=1)
					{
					info[i]="NULL";
					i++;
					continue;
					}
				info[i]=tmp;
				i++;
				continue;
			}
			else 
				{
				String[] tmpl = tmp.split("��");
				if(tmpl.length<2)
					{
					info[i]="NULL";
					i++;
					continue;
					}
				info[i] = tmpl[1];
				i++;
				}	
		}
		Link2Mysql.link(info,connection,statement);
	}
	
	Link2MysqlThread(File[] files,Connection conn,Statement stat,int n,ExecutorService exe) throws Exception
	{
		info = files;
		connection = conn;
		state = stat;
		count = n;
		exec = exe;
	}
	
	public void run()
	{
		try {
			if(exec.isTerminated())
			{
				for(int i=count-1;i<info.length;i+=10)
			{
				getTeacherInfo(info[i].getPath().replace("\\", "\\\\"),connection,state);
			}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.yield();
	}
}

class TraversalUrl implements Runnable
{
	private File input;
	private int count;
	private Document document;
	private Elements links;
	private Pattern selectUrl;
	private Pattern selectName;
	private Connection connection;
	private Statement state;
	
	TraversalUrl(File file,int n,Connection conn,Statement stat) throws Exception
	{
		input = file;
		document = Jsoup.parse(input, "UTF-8");
		links = document.select("a[href*=\"view.php?aid\"]");
		selectUrl = Pattern.compile("view.php+.+aid+.+[0-9]");
		selectName = Pattern.compile("[\u4e00-\u9fa5]{1,}");
		count = n;
		connection = conn;
		state = stat;
	}
	public void Traversal(File input) throws Exception
	{
		int i = count;
		while(i<=links.size())
		{
			Matcher a = selectUrl.matcher(links.get(i-1).toString());
			Matcher b = selectName.matcher(links.get(i-1).toString());
			while(a.find()&&b.find())
				{
				System.out.println(b.group());
				String url = "http://cs.whu.edu.cn/plus/"+a.group();
				String file = ".\\javaThread\\"+b.group()+".txt";
				Main2014302580187.getInfoHttp(url,file);
				Main2014302580187.getTeacherInfo(file,connection,state);
				}
			i+=10;
		}
	}
	public void run()
	{
			try {		
				this.Traversal(input);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

