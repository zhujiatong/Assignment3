import java.net.URL;
import java.io.*;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.*;

public class Main2014302580187 {
	private static long startTime;
	public static long afterTime;
	
	static void getInfo() throws Exception{
	String urlPath = "http://cs.whu.edu.cn/plus/list.php?tid=36";
	String filePath = "C:\\Users\\SilverCrux\\Desktop\\text.txt";
	URL url = new URL(urlPath);
	URLConnection connection = url.openConnection();
	InputStream in = connection.getInputStream();
	FileOutputStream out = new FileOutputStream(filePath);
	byte[] buffer = new byte[1024];
	while(in.read(buffer) != -1)
	{
		out.write(buffer);
	}
	in.close();
	out.close();
	}
	
	static void getInfoHttp(String urlPath,String filePath) throws Exception
	{

		URL url = new URL(urlPath);
		HttpRequest request = new HttpRequest(url,"GET");
		FileOutputStream out = new FileOutputStream(filePath);
		request.receive(out);
		out.close();
	}
	
	static void Traversal(File input) throws Exception
	{
		Document document = Jsoup.parse(input, "UTF-8");
		Elements links = document.select("a[href*=\"view.php?aid\"]");
		int i = 0;
		Pattern selectUrl = Pattern.compile("view.php+.+aid+.+[0-9]");
		Pattern selectName = Pattern.compile("[\u4e00-\u9fa5]{1,}");
		while(i<links.size())
		{
			Matcher a = selectUrl.matcher(links.get(i).toString());
			Matcher b = selectName.matcher(links.get(i).toString());
			while(a.find()&&b.find())
				{
				//System.out.println(b.group());
				String url = "http://cs.whu.edu.cn/plus/"+a.group();
				String file = ".\\java\\"+b.group()+".txt";
				getInfoHttp(url,file);
				}
			i++;
		}
	}
	
	static void getTeacherInfo(String filePath,Connection connection,Statement statement) throws Exception
	{
		File file = new File(filePath);
		//System.out.println(file.exists());
		Document document = Jsoup.parse(file,"UTF-8");
		//System.out.println(filePath);
		Elements elements = document.select("ul[class*=\"about_info fn_left\"] li,div[class*=\"info_list_ct\"]");
		//System.out.println(elements.size());
		String[] info = new String[18];
		int i = 0;
		if(elements.size()<18)
			return;
		while(i<18)
		{
		
			if(elements.get(i).text().equals(""))
				{
				info[i]="NULL";
				i++;
				continue;
				}		
			if(i>=9)
			{
				if(elements.get(i).text().length()<=1)
					{
					info[i]="NULL";
					i++;
					continue;
					}
				info[i]=elements.get(i).text();
				i++;
				continue;
			}
			else 
				{
				String[] tmp = elements.get(i).text().split("��");
				if(tmp.length<2)
					{
					info[i]="NULL";
					i++;
					continue;
					}
				info[i] = tmp[1];
				i++;
				}	
		}
		//System.out.println(info[1]);
		Link2Mysql.link(info,connection,statement);
	}
	
	public static void main(String args[]) throws Exception
	{
		
		String filePath = ".\\text.txt";
		String urlPath = "http://cs.whu.edu.cn/plus/list.php?tid=36";
		getInfoHttp(urlPath,filePath);
		File file = new File(filePath);
		//System.out.println(file.getName());
		startTime = System.currentTimeMillis();
		Traversal(file);
		File[] files = new File(".\\java").listFiles();
		String url = "jdbc:mysql://127.0.0.1:3306/assignment?user=root&password=393333&useUnicode=true&characterEncoding=utf8";
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection(url);
		Statement state = connection.createStatement();
		state.executeUpdate("drop table if exists teacher");
		state.executeUpdate("create table teacher(ID int not null auto_increment,"
				+ "Name varchar(5),"
				+ "HomePage varchar(50) NULL,"
				+ "Sex varchar(1) NULL,"
				+ "Office varchar(50) NULL,"
				+ "Bachelor varchar(50) NULL,"
				+ "Phone varchar(50) NULL,"
				+ "Place varchar(50) NULL,"
				+ "Email varchar(50) NULL,"
				+ "Teacher varchar(50) NULL,"
				+ "ResearchDirection TEXT NULL,"
				+ "Education TEXT NULL,"
				+ "Experience TEXT NULL,"
				+ "Lessons TEXT NULL,"
				+ "Thesis TEXT NULL,"
				+ "Issue TEXT NULL,"
				+ "WorkGroup TEXT NULL,"
				+ "Awards TEXT NULL,"
				+ "Service TEXT NULL,"
				+ "PRIMARY KEY(ID))");
		
		//���߳���ȡ
		for(File f:files)
		{
			String str = f.getPath().replace("\\", "\\\\");
			//System.out.println(str);
		    getTeacherInfo(str,connection,state);
		}
		
		System.out.println("���߳�ʱ�䣺"+String.valueOf(System.currentTimeMillis()-startTime));
		startTime = System.currentTimeMillis();
		
		//���߳���ȡ
		//ExecutorService exec = Executors.newCachedThreadPool();
		//for(int i=1;i<=10;i++)
	    // {
		//exec.execute(new TraversalUrl(file,i,connection,state));
	    // }		
		//exec.shutdown();
		//while(!exec.isTerminated())
		//{
		//}
		//System.out.println("���߳�ʱ�䣺"+String.valueOf(System.currentTimeMillis()-startTime));

	}
}

	
