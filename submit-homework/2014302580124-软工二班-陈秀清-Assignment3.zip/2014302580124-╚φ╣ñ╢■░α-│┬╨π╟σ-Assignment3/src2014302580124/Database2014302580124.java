import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class Database2014302580124 {
	public String url = "jdbc:mysql://localhost:3306/teacher_infornation";
    public String driver = "com.mysql.jdbc.Driver";
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    String sql;
    PreparedStatement ps=null;
    public Connection getConn(){
    	 try {
             Class.forName(driver);
             conn = (Connection) DriverManager.getConnection(url, "root", "cxqcxq1995");
             stmt = conn.createStatement();
                
             System.out.println("���ݿ����ӳɹ���");} catch (ClassNotFoundException e) {
                 System.out.println("���ݿ����������ڣ�");
                 System.out.println(e.toString());             
             } catch (SQLException e) {
                 System.out.println("SQL����");
                 System.out.println(e.toString());
             } finally {
            	
                 }
    return conn;	
    }//end method getconn 
}//end class Database2014302580124
