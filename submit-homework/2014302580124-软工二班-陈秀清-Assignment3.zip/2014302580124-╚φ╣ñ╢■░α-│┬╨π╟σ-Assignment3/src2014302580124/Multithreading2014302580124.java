import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
//���߳�
public class Multithreading2014302580124 {
	ArrayList<String> allurlset=new ArrayList<String>();
	ArrayList<String>notCrawlurlSet=new ArrayList<String>();
	int threadCount=10;//�߳�����
	int count=0;//�ж��ٸ��̴߳���wait״̬��
	public static final Object signal=new Object();//�̼߳�ͨ�ű���
	private Crawl2014302580124 crawl=new Crawl2014302580124();
	
public Multithreading2014302580124(Vector<String> urlset){
	for(int i=0;i<urlset.size();i++) {
		String url=(String) urlset.get(i);
		addUrl(url);
		};//��url ����
	long start=System.currentTimeMillis();
	begin();
	while(true){
		if(notCrawlurlSet.isEmpty()&&Thread.activeCount()==1||count==threadCount){
			long end=System.currentTimeMillis();
		//	System.out.println("�ܹ�����"+allurlset.size()+"����ҳ");
			System.out.println("���̺߳�ʱ"+(end-start)/1000+"��");
			System.exit(1);
			break;
		}//end if
           
	}//end while
}//end construction
private void begin(){
	for(int i=0;i<threadCount;i++){
		new Thread(new Runnable(){
			public void run(){
				while(true){
					String temp=getAUrl();
					if(temp!=null){
			          // System.out.println(temp);
						try {
							crawl.readHTML(temp);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else{
						synchronized(signal){
							try{
								count++;
								//System.out.println("��ǰ��"+count+"���߳��ڵȴ�");
								signal.wait();	
							}catch(InterruptedException e){
								e.printStackTrace();
							}
						}
					}
				}
			}
		},"thread-"+i).start();
	}
}
public synchronized String getAUrl(){
	if(notCrawlurlSet.isEmpty()) return null;
	String tempAUrl;
	tempAUrl=notCrawlurlSet.get(0);
	notCrawlurlSet.remove(0);
	return tempAUrl;
}// end method getAUrl
public synchronized void addUrl(String url){
	notCrawlurlSet.add(url);
	allurlset.add(url);
}//end method addUrl
}//end class Multithreading2014302580124
