import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Vector;

import com.mysql.jdbc.PreparedStatement;

public class Main2014302580124 {
	
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
String preurl="http://cs.whu.edu.cn/plus/view.php?aid=";
String[] sufurl={"1620","1626","1610","1618","1614","1722","1723","1628","1569","1568"};
Vector<String> urlset=new Vector<String>(10);
Vector<String> urlset1=new Vector<String>(10);
for(int i=0;i<sufurl.length;i++){
	urlset.add(preurl+sufurl[i]);
//System.out.println(urlset[i]);
	}
for(int i=1589;i<1599;i++){
	urlset1.add(preurl+i);
}
//���߳���ȡ
Singlethreading2014302580124 s=new Singlethreading2014302580124(urlset);
//���߳���ȡ
Multithreading2014302580124 m=new Multithreading2014302580124(urlset1);

	}//end main method

}//end  class Main2014302580124
