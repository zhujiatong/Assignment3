import java.sql.SQLException;
import java.util.Vector;

public class Singlethreading2014302580124 {
	private Crawl2014302580124 crawl=new Crawl2014302580124();
public Singlethreading2014302580124(Vector<String> urlset) throws SQLException{
	Vector<String> myurl;
	myurl=urlset;
	long start=System.currentTimeMillis();
	for(int i=0;i<myurl.size();i++){
	String url=(String) myurl.get(i);
	//System.out.println(url);
		crawl.readHTML(url);
		
	}
	
	
	long end=System.currentTimeMillis();
	System.out.println("���̺߳�ʱ"+(end-start)/1000+"�룡");
}//end construction
}//end class Singlethreading2014302580124
