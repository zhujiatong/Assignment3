import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import com.mysql.jdbc.PreparedStatement;
//��jsoup��ȡ������ҳ
public class Crawl2014302580124 {
	public String mname=null;
	public String mphone=null;
	public String memail=null;
	public String mintroduction=null;
	public static  Database2014302580124 teacher_information=new Database2014302580124();
	public static Connection conn=teacher_information.getConn();
	public static String sql;
	public static PreparedStatement ps=null;
	public static int n=0;
	public void readHTML(String url) throws SQLException
{       
		String myurl=url;
		try{ Document mydoc=Jsoup.connect(myurl).get();
		Elements elements1=mydoc.select("[class=about_info fn_left]");
	    Elements information=elements1.select("li");
	    String introduction=information.get(3).text();
	    String name=information.get(0).text();
	    String phone=information.get(5).text();
	    String email=information.get(7).text();
	    this.mname=name;
	    this.mphone=phone;
	    this.memail=email;
	   this.mintroduction=introduction;  
	   //д�����ݿ�
	sql="insert into teacher_table(name,phone,email,introduction)values('"+this.mname+"','"+this.mphone+"','"+this.memail+"','"+this.mintroduction+"');";
	   ps=(PreparedStatement) conn.prepareStatement(sql);
	   ps.executeLargeUpdate(sql);
	   n++;
	   if(n>=20){
	   ps.close();
	   conn.close();}
	   // System.out.println(name);
	   // System.out.println(phone); 
	    //System.out.println(email);
	  //  System.out.println(introduction);
		}catch(IOException e){
			e.printStackTrace();
		}
	}//end construction
}//end class Crawl2014302580124
