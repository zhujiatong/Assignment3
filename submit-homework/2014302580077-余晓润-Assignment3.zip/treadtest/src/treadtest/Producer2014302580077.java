package treadtest;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Producer2014302580077 {
	private Document tinf;  
	public String name;
	public String direction;
	public String inf;
	public String email;
	public String tel;
public void getDoc(String url){
	  try {
		tinf =Jsoup.connect(url).get(); 
	} catch (IOException e) {
		e.printStackTrace();
	}
}
public void process() {
Element Name=tinf.getElementsByTag("h3").first();
	name=Name.text();                                                              //�ҵ�����
	Element infs=tinf.getElementsByTag("p").first();
	direction=infs.childNode(2).toString();                               //�ҵ��о�����
	inf=infs.childNode(0).toString();                                         //�ҵ����
	Pattern p=Pattern.compile("\\w+@\\w+\\.\\w+.\\w+");
	  String u=infs.text();                                                                           
	 Matcher m=p.matcher(u);
	try{ m.find();
	email=m.group();}
	catch(IllegalStateException e){
		email="��������";
	}
	Pattern p1=Pattern.compile("(0\\d{2}-\\d{8})|([0-9]{11})");                                                
	  Matcher m1=p1.matcher(u);
	  try{  m1.find();
	     tel=m1.group();  }
	  catch(IllegalStateException e){
		  tel="��������";//�ҵ��绰
	  }
}}