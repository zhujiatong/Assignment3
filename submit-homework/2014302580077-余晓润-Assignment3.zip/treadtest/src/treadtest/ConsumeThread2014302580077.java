package treadtest;
public class ConsumeThread2014302580077 extends Thread{
 public PcLock2014302580077 pc;
 public ConsumeThread2014302580077(PcLock2014302580077 pc){
	 this.pc=pc;
 }
 public void run(){
	 long start = System.currentTimeMillis();
	 while(pc.Storage.size()>0||pc.prfinish==false){
		 pc.consume();
	 }
	 System.out.println("Consume end");
	 long end = System.currentTimeMillis();
	 System.out.println("���߳�����ʱ�䣺" + (end - start));
 }
}

