package treadtest;

import java.io.IOException;
import java.util.Vector;

public class PcLock2014302580077 {
public Spider2014302580077 sp;
private Producer2014302580077 pd;
private Consumer2014302580077 cs;
public Vector<String[]> Storage;
public boolean prfinish=false;
	public PcLock2014302580077(){
		sp=new Spider2014302580077();
		sp.getDoc("http://staff.whu.edu.cn/index.jsp?lang=cn");
		sp.process();
	    prfinish=false;
		Storage=new Vector();
	}
	public synchronized void produce(){
		while(Storage.size()>10){
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(sp.links.size()>0){
		pd=new Producer2014302580077();
		pd.getDoc((String)(sp.links.lastElement()));
		sp.links.remove(sp.links.lastElement());
		pd.process();
		String[] storage=new String[5];
		storage[0]=pd.name;
		storage[1]=pd.inf;
		storage[2]=pd.email;
		storage[3]=pd.tel;
		storage[4]=pd.direction;
		Storage.add(storage);}
		notifyAll();
	}
	public synchronized void consume(){
		while(Storage.size()==0&&prfinish==false){
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		cs=new Consumer2014302580077();
		try {
			if(Storage.size()>0){
			cs.process(Storage.lastElement());
			Storage.remove(Storage.lastElement());}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		notifyAll();
	}
	
	public static void main(String[] args) throws IOException {
		PcLock2014302580077 pl=new PcLock2014302580077();
		long start = System.currentTimeMillis();
		for(int i=0;i<100;i++){
			pl.produce();
			pl.consume();
		}
		long end=System.currentTimeMillis();
		 System.out.println("���߳�����ʱ�䣺" + (end - start));
		 PcLock2014302580077 pl2=new PcLock2014302580077();
		 new ProduceThread2014302580077(pl2).start();
			new ConsumeThread2014302580077(pl2).start();
	}
	
}

