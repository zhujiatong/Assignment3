package treadtest;
import java.sql.*;
public class Consumer2014302580077 {
	public String name;
	public String direction;
	public String inf;
	public String email;
	public String tel;
	public Consumer2014302580077(){
	}
	public void process(String[] s) throws ClassNotFoundException{
		name=s[0];
		inf=s[1];
		email=s[2];
		tel=s[3];
		direction=s[4];
		if(direction.length()>50){
			direction="����";
		}
		 Class.forName("com.mysql.jdbc.Driver");
		try {
			Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/teacherinf","root","134679");
			Statement statement=conn.createStatement();
		statement.executeUpdate("Insert into tinf(name,inf,email,tel,field) values('"+name+"','"+inf+"','"+email+"','"+tel+"','"+direction+"');");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
