package treadtest;

import java.io.IOException;
import java.util.Vector;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Spider2014302580077 {
	private Document homepage;  
	public Vector links;
	public void getDoc(String url){                        //���document����
  	  try {
			homepage =Jsoup.connect(url).get(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
	public void process(){
		Elements hrefs=homepage.getElementsByTag("p");
		hrefs=hrefs.select("a");
		links=new Vector();
		for(Element href:hrefs){
		  links.addElement(href.attr("abs:href"));
		}
}
	
}
