package treadtest;

public class ProduceThread2014302580077 extends Thread{
 public PcLock2014302580077 pc;
 public ProduceThread2014302580077(PcLock2014302580077 pc){
	 this.pc=pc;
 }
 public void run(){
	 while(pc.sp.links.size()>0){
		 pc.produce();
	 }
	pc.prfinish=true;
	 System.out.println("Produce end");
 }
}
