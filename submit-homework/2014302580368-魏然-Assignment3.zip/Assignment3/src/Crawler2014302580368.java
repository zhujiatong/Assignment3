import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.imageio.stream.FileImageOutputStream;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Crawler2014302580368 extends Thread {
	public static String[] getUrl() throws IOException{
		String[]urls=new String[5];
		int i=0;
        Document doc = Jsoup.connect("http://spfdu.fudan.edu.cn/Attr_Tutor_list.aspx?BID=3&SID=23").get();
		Element id=doc.getElementById("Ctrl_OtherList1_Panel1");
		Element ul = id.getElementsByTag("ul").get(1);
		Elements links=ul.select("a[href]");
		for(Element link:links){
			String linkHref = link.attr("abs:href");
			urls[i]=linkHref;
			i++;
			
		}
	return urls;
	} 
	public Document getHtml(String url) throws IOException{
		Document doc = Jsoup.connect(url).get();
		return doc;
	}
	
	
	
}


