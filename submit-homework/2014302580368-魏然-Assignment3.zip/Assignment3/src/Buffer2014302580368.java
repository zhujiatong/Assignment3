import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.nodes.Document;


public class Buffer2014302580368{
	public Buffer2014302580368()
	{doc=new Document[5];}
	private Document[] doc;
	//static ArrayList<Document>Info=new ArrayList<Document>();
	Crawler2014302580368 c=new Crawler2014302580368() ;
	public synchronized void InList(String url) throws IOException{
		Document d=c.getHtml(url);
		//Info.add(d);		
		for(int i=0;i<5;i++)
		{
			if(doc[i]==null)
			{
				doc[i]=d;
				break;
			}
		}
	}
	
	public Document getBuffer(int i)
	{
		//return Info.get(i);
		return doc[i];
	}
	
	
}
