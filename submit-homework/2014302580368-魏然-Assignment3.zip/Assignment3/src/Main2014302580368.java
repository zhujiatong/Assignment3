import java.io.IOException;

import org.jsoup.nodes.Document;

import JDBC.ProfessorDao2014302580368;


public class Main2014302580368 {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		long start1=System.currentTimeMillis();   //��ȡ��ʼʱ��
		SingleThread2014302580368 t=new SingleThread2014302580368();
		t.test();
		
		long end1=System.currentTimeMillis(); //��ȡ����ʱ��
		
		
		
		
		long start=System.currentTimeMillis();   //��ȡ��ʼʱ��
		// TODO Auto-generated method stub
		final String[]urls=Crawler2014302580368.getUrl();
		final Buffer2014302580368 b=new Buffer2014302580368();
		final Analysis2014302580368 a=new Analysis2014302580368();
		Thread[] ab=new Thread[5];		
		for(int i=0;i<urls.length;i++){
			final int weiran=i;
			ab[i]=new Thread(new Runnable(){			
				public void run()
				{
					
					try {
						b.InList(urls[weiran]);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			
		}
		
		Thread mutiThread=new Thread(new Runnable()
		{		
			public void run()
			{
				
				for(int i=0;i<5;i++){
					while(b.getBuffer(i)==null)
					{
						try {
							Thread.sleep(10);
							System.out.println("sleep");
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
					
					
					try {
						
						a.Intodb(b.getBuffer(i));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
		});
		
		
		
		for(int i=0;i<5;i++)
		{
			ab[i].start();
		}	
		for(int i=0;i<5;i++)
		{
			ab[i].join();
		}	
		
		mutiThread.start();
		mutiThread.join();
		
		

		
		long end=System.currentTimeMillis(); //��ȡ����ʱ��
		System.out.println("���߳�ʱ�䣺 "+(end1-start1)+"ms");	
		System.out.println("���߳�ʱ�䣺 "+(end-start)+"ms");	
		
	}

}
