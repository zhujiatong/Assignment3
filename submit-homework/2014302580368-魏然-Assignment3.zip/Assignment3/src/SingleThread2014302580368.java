

	import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

	import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import JDBC.Professor2014302580368;
import JDBC.ProfessorDao2014302580368;


	public class SingleThread2014302580368 {
		public void test(){
		try{
			ProfessorDao2014302580368 pd=new ProfessorDao2014302580368();
		Document doc = Jsoup.connect("http://spfdu.fudan.edu.cn/Attr_Tutor_list.aspx?BID=3&SID=23").get();
		
		Element id=doc.getElementById("Ctrl_OtherList1_Panel1");
		Element ul = id.getElementsByTag("ul").get(1);
		Elements links=ul.select("a[href]");
		for (Element link : links) {
			Professor2014302580368 p=new Professor2014302580368();
		  String linkHref = link.attr("abs:href");
		  Document document = Jsoup.connect(linkHref).get(); 
		  p.setName(document.getElementById("Tea_Names").text());
		  String h=document.getElementsByAttributeValue("id","introduct").get(1).text();
		  p.setIntro(document.getElementById("Tea_Jobs").text());
		  p.setInterest(h);
		  Elements content=document.getElementsByTag("p");
		  for(Element c:content){
			  String con=c.text();
			  Pattern pattern=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
			  Pattern pattern1=Pattern.compile("[0-9]{3}-[0-9]{8}");
			  Matcher matcher = pattern.matcher(con);
			  Matcher matcher1 = pattern1.matcher(con);
			  if(matcher1.find())
				 p.setTel(matcher1.group());
			  if(matcher.find())
				 p.setEmail(matcher.group());
			  
			  
		  }
		  
		 pd.savePro(p);
		}
		}catch(IOException e) { 
	        // TODO Auto-generated catch block 
		    e.printStackTrace();
		    } 
	}
	
}
