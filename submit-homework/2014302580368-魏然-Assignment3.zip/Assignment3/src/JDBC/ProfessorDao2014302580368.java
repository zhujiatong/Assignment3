package JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProfessorDao2014302580368 {
	public void savePro(Professor2014302580368 p){
	String sql="insert into Professor values(?,?,?,?,?)";
	DBUtil2014302580368 util=new DBUtil2014302580368();
	Connection conn=util.openConnection();
	try{
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, p.getName());
		pstmt.setString(2, p.getEmail());
		pstmt.setString(3, p.getTel());
		pstmt.setString(4, p.getInterest());
		pstmt.setString(5, p.getIntro());
		pstmt.executeUpdate();
	}catch(SQLException e){
		e.printStackTrace();
	}finally{
		util.closeConn(conn);
	}
	}
}