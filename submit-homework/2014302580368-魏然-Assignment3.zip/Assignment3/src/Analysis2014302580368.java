import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import JDBC.Professor2014302580368;
import JDBC.ProfessorDao2014302580368;


public class Analysis2014302580368 {
	ProfessorDao2014302580368 pd=new ProfessorDao2014302580368();
	Professor2014302580368 p=new Professor2014302580368();
	public void Intodb(Document doc) throws IOException{
	//Document document = Jsoup.parse(file, "UTF-8");
		p.setName(doc.getElementById("Tea_Names").text());
	  String h=doc.getElementsByAttributeValue("id","introduct").get(1).text();
	  p.setIntro(doc.getElementById("Tea_Jobs").text());
	  p.setInterest(h);
	  Elements content=doc.getElementsByTag("p");
	  for(Element c:content){
		  String con=c.text();
		  Pattern pattern=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		  Pattern pattern1=Pattern.compile("[0-9]{3}-[0-9]{8}");
		  Matcher matcher = pattern.matcher(con);
		  Matcher matcher1 = pattern1.matcher(con);
		  if(matcher1.find())
			  p.setTel(matcher1.group());
		  if(matcher.find())
			  p.setEmail(matcher.group());
		  
		  
	  }
	  pd.savePro(p);
	} 
}
