import java.io.IOException;


public class MulThread1 implements Runnable{
	private int num;
	SQL sql = new SQL();
	public MulThread1(int i) throws IOException{
		num = i;
		
	}
	public void run(){
		sql.buildForm("info2");
		for(int j=num; j<10+num; j++){
			try {
				sql.execute("info2",j);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
