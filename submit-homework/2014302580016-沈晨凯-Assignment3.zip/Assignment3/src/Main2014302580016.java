import java.io.IOException;




public class Main2014302580016 {
	
	
	
public static void main(String [] args) throws IOException{
	
	//���߳�
	singleLine();
	//���߳�
	mulLine();
	
}
public static void singleLine() throws IOException{
	long start=System.currentTimeMillis();
	SQL sql = new SQL();
	sql.buildForm("info1");
	for(int j=0; j<50;j++){
	sql.execute("info1",j);
	}
	long end=System.currentTimeMillis();
	System.out.println("���̺߳�ʱ : "+(end-start)+"ms");
}
public static void mulLine() throws IOException{
	//long start=System.currentTimeMillis();
//	MulThread multi1 =  new MulThread();
//	Thread thread1;
//	thread1 = new Thread(multi1);
//	thread1.setName("�߳�1");
//	
//	thread1.start();
	MulThread1 mul1 = new MulThread1(0);
	MulThread1 mul2 = new MulThread1(10);
	MulThread1 mul3 = new MulThread1(20);
	MulThread1 mul4 = new MulThread1(30);
	MulThread1 mul5 = new MulThread1(40);
	Thread thread1 = new Thread(mul1);
	Thread thread2 = new Thread(mul2);
	Thread thread3 = new Thread(mul3);
	Thread thread4 = new Thread(mul4);
	Thread thread5 = new Thread(mul5);
	
	long start=System.currentTimeMillis();
	thread1.start();
	thread2.start();
	thread3.start();
	thread4.start();
	thread5.start();
	while(true){
		if((!thread1.isAlive()) &&(!thread2.isAlive())&&(!thread3.isAlive())&&(!thread4.isAlive())&&(!thread5.isAlive()) ){
			break;
		}
	}
	long end =System.currentTimeMillis();
			System.out.println("���̺߳�ʱ : "+(end-start)+"ms");

}
}


