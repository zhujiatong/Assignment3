import java.util.ArrayList;


public class Buffer {
	ArrayList<String[]> list=new ArrayList<String[]>();
	String[] detail=new String[4];
	boolean signal=(list.isEmpty());
	//boolean signal=true;
	private String name;
	private String brief;
	private String field;
	private String contact;
	
	public void addTeacher(){
		list.add(detail);
	}
	
	public boolean getSignal(){
		return this.signal;
	}
	
	public void set(){
		this.name=list.get(0)[0];
		this.brief=list.get(0)[1];
		this.field=list.get(0)[2];
		this.contact=list.get(0)[3];
		
		list.remove(0);
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getBrief(){
		return this.brief;
	}
	
	public String getField(){
		return this.field;
	}
	
	public String getContact(){
		return this.contact;
	}
	
}
