import java.io.IOException;
import java.util.ArrayList;


public class Main2014302580267 {
	public static void main(String[]args) throws IOException{
		long startTime = System.currentTimeMillis();
		
	//ArrayList<ArrayList<String>> list=new ArrayList<ArrayList<String>>();
	//ArrayList<String> detail=new ArrayList<String>();
	Buffer buffer=new Buffer();
	Write write=new Write(buffer);
	Read read=new Read(buffer);
	
	read.getLinks();
	write.load();
	
	Thread t1=new Thread(read);
	Thread t2=new Thread(write);
	
	t1.start();
	t2.start();
	System.out.println("多线程时间: " + (System.currentTimeMillis() - startTime));
	long startTime2 = System.currentTimeMillis();
	read.run2();
	write.run2();
	System.out.println("多线程时间: " + (System.currentTimeMillis() - startTime2));
	}
	 
}
