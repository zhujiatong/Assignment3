
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;



import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Read implements Runnable{
	private Buffer buffer;
	private ArrayList<String> links=new ArrayList<String>();
	private ArrayList<String> informations=new ArrayList<String>();
	private String[] name=new String[14];
	
	public Read(Buffer buffer){
		this.buffer=buffer;
	}
	
	public static String readHtml(String myurl) {
	    StringBuffer sb = new StringBuffer("");
	    URL url;
	    try {
	        url = new URL(myurl);
	        BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream(), "utf-8"));
	        String s = "";
	        while ((s = br.readLine()) != null) {
	            sb.append(s + "\r\n");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return sb.toString();
	}
	
	
	public void getLinks() throws IOException{
		Document doc = Jsoup.connect("http://sc.xidian.edu.cn/html/teacher/daoshixinxi/").get();
		Elements trs=doc.getElementsByClass("middle_left_box1").get(0).getElementsByTag("tr");
		Element t=trs.get(2).getElementsByTag("td").get(1);
		Elements ele=t.getElementsByTag("a");
		
		for(int i=0;i<14;i++){
			String link=ele.get(i).attr("href");
			links.add(link);
			name[i]=ele.get(i).text();
		}
	}
	
	public String getName(int i){
		return name[i];
	}
	
	public void readInformations(int i){
		Document d=Jsoup.parse(readHtml(links.get(i)));
		
		String brief="";
		Elements briefs=d.getElementById("n2").getAllElements();
		int n1=briefs.size();
		for(int j=0;j<n1;j++)
			brief=brief+briefs.get(j).text();
		
		String field=d.getElementById("n1").getElementsByTag("p").get(0).text();
		
		String contact="";
		Elements contacts=d.getElementById("n3").getElementsByTag("p");
		int n2=contacts.size();
		for(int j=0;j<n2;j++)
			contact=contact+contacts.get(j).text();
		
		
		if(this.getName(i)==null)
			this.informations.add("��");
		this.informations.add(this.getName(i));
		if(brief==null)
			this.informations.add("��");
		this.informations.add(brief);
		if(field==null)
			this.informations.add("��");
		this.informations.add(field);
		if(contact==null)
			this.informations.add("��");
		this.informations.add(contact);
		
	}
	
	public synchronized void writeToBuffer(){
		for(int i=0;i<4;i++){
			buffer.detail[i]=this.informations.get(0);
			this.informations.remove(0);
		}
		buffer.addTeacher();
		//buffer.signal=false;
		
	}
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		for(int i=1;i<14;i++){
			
			readInformations(i);
			synchronized(buffer){
			while(!buffer.list.isEmpty()){
				try {
					buffer.wait();
				} catch (InterruptedException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
				buffer.notify();
			}
				
				writeToBuffer();
				//System.out.println(buffer.list.get(0)[0]);
				//System.out.println("y");
				buffer.notify();
			
			}
		}
		
		
			//try {
			//	buffer.wait();
			//} catch (InterruptedException e) {
			//	// TODO �Զ����ɵ� catch ��
			//	e.printStackTrace();
			//}
			//buffer.notify();
		
		}
	public void run2(){
for(int i=1;i<14;i++){
			
			readInformations(i);
			
				
				writeToBuffer();
				//System.out.println(buffer.list.get(0)[0]);
				//System.out.println("y");
			
	}
		
	}
	}








