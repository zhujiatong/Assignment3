import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Write implements Runnable{
	private Buffer buffer;
	private String url="jdbc:mysql://localhost:3306/Teacher?useUnicode=true&characterEncoding=utf-8";
	private String user="root";
	private String password="19950707";
	private Statement st;
	
	
	public Write(Buffer buffer){
		this.buffer=buffer;
	}
	
	public void load(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url, user, password);
			st=conn.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("Fail to conect to the database!");
			e.printStackTrace();
		}
		
	}
	
	public synchronized void writeToMysql(){
		buffer.set();
		System.out.println(buffer.getName());
		String sql="insert into TeacherList(name,brief,field,contact) values('"+buffer.getName()+"','"+buffer.getBrief()+"','"+buffer.getField()+"','"+buffer.getContact()+"');";
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		synchronized(buffer){
		while(buffer.list.isEmpty()){
			try {
				buffer.wait();
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			buffer.notify();
		}
			writeToMysql();
			System.out.println("y");
			//buffer.signal=true;
		
		
		//try {
		//	buffer.wait();
		//} catch (InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
		//	e.printStackTrace();
		//}
		//buffer.notify();
		}
	}
	
	public void run2() {
		// TODO �Զ����ɵķ������
		
			writeToMysql();
			
			//buffer.signal=true;
		
		
		//try {
		//	buffer.wait();
		//} catch (InterruptedException e) {
			// TODO �Զ����ɵ� catch ��
		//	e.printStackTrace();
		//}
		//buffer.notify();
		}
	}
	

