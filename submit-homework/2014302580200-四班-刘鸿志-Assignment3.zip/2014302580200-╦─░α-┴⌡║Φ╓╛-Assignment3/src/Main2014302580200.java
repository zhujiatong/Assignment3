import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580200
{
	private Long TimeOfOneThread;
	private String[] Names; 
	private String[] DirectionsOfStudy;
	private String[] EmailsOrPhonenumbers; 
	private String[] Introductions; 
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException
	{
		GetUrls2014302580200 p = new GetUrls2014302580200();
		Main2014302580200 q = new Main2014302580200();
		q.getContentsByOneThread(p.getUrlSource());
		q.showTimeOfOneThread();
		Operation2014302580200 r = new Operation2014302580200();
		Thread t1 = new Thread(r);
		Thread t2 = new Thread(r);
		Thread t3 = new Thread(r);
		Thread t4 = new Thread(r);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}
	
	public void showTimeOfOneThread()
	{
		System.out.println("���߳���Ҫʱ�䣺");
		System.out.println(TimeOfOneThread + "ms");
	}
	
	public void getContentsByOneThread(String[] links) throws IOException, ClassNotFoundException, SQLException
	{
		long TimeOfStart = System.currentTimeMillis(); 	
		Names = new String[100];
		EmailsOrPhonenumbers = new String[100];
		DirectionsOfStudy = new String[100];
		Introductions = new String[100];
		
		String regx1 = "[0-9]{3}-[0-9]{8}|[0-9]{11}|[0-9]{8}(?!@)";
		String regx2 = "[a-zA-z_0-9]+@+[a-zA-Z0-9]+(\\.[a-zA-Z]+)";
		String regx3 = "[\u7814]+[\u7a76]+[\u65b9]+[\u5411]+[\uff1a]+ [\u4e00-\u9fa5]{0,10}";
		Pattern p1 = Pattern.compile(regx1);
		Pattern p2 = Pattern.compile(regx2);
		Pattern p3 = Pattern.compile(regx3);
		
		for(int i = 0; i <= 99 ; i++)
		{
			Document PersonalHomepage = Jsoup.connect(links[i]).get();
			Elements content1 = PersonalHomepage.select("div[class = details col-md-10 col-sm-9 col-xs-7]");
			Elements ElemOfNames = content1.select("[class = title]");
			Names[i] = ElemOfNames.text();
			
			Elements ElemOfIntroduction = PersonalHomepage.select("div[class = details col-md-12 col-sm-12 col-xs-12]");
			if(ElemOfIntroduction.text().length() >= 254)
			{
				Introductions[i] = ElemOfIntroduction.text().substring(0, 254);
			}
			else
			{
				Introductions[i] = ElemOfIntroduction.text();
			}
			Matcher m1 = p1.matcher(content1.text());
			Matcher m2 = p2.matcher(content1.text());
			Matcher m3 = p3.matcher(content1.text());
			
			while(m3.find())
			{
				DirectionsOfStudy[i] = m3.group();
			}
			while(m1.find())
			{
				EmailsOrPhonenumbers[i] = m1.group() + " ";
			}
			while(m2.find())
			{
				EmailsOrPhonenumbers[i] = EmailsOrPhonenumbers[i] + m2.group();
			}
		}
		
		final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		final String DB_URL = "jdbc:mysql://localhost:3306/demo";
		final String USER = "root";
		final String PASSWORD = "liu19960623";
		
		Connection conn = null;
		Statement stmt = null;
		
		
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			stmt = conn.createStatement();
			String sql = "CREATE TABLE OneThread " +
	                   " (Names VARCHAR(255), " +
	                   " EmaisOrPhonenumbers VARCHAR(255), " + 
	                   " DirectionsOfStudy VARCHAR(255), " + 
	                   " Introductions VARCHAR(255)) " ; 
			stmt.executeUpdate(sql);
			
			for(int i = 0 ; i <= 99 ; i++)
			{
			sql = "INSERT INTO OneThread " + "VALUES ('" + Names[i] + "','" + EmailsOrPhonenumbers[i]
					+ "','" + DirectionsOfStudy[i] + "','" + Introductions[i] + "')" ;
			stmt.executeUpdate(sql);
			}
					
			
		         if(stmt!=null)
		            conn.close();
		    
		         if(conn!=null)
		            conn.close();
		      
		long TimeOfEnd = System.currentTimeMillis();
		TimeOfOneThread = TimeOfEnd - TimeOfStart;
	}	
}
