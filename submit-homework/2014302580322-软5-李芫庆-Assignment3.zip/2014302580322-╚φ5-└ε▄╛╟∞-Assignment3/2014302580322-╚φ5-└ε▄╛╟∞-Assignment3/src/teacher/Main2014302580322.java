package teacher;

public class Main2014302580322 {

	/**
	 * 
	 * ��ܾ�� 2014302580322   ��5
	 * 
	 */
	public static void main(String[] args)  {
		GUI2014302580322 gui2014302580322=new GUI2014302580322();
	}
	
	
}

