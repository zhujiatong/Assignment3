package teacher;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
public class GUI2014302580322 extends JFrame implements ActionListener {
	private JButton jbutton[]=new JButton[2];
	private JTextArea[] jtext=new JTextArea[2];
		public GUI2014302580322()
		{
			//�Դ��ڽ���������������������
			super("���̵߳��߳�");
			setBounds(400,150,600,500);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			Container container=getContentPane();
			container.setLayout(null);
			jbutton[1]=new JButton("���߳�");
			jbutton[1].setBounds(100,150,100,30);
			jbutton[1].addActionListener(this);
			jbutton[1].setForeground(Color.yellow);
			container.add(jbutton[1]);
			jbutton[0]=new JButton("���߳�");
			jbutton[0].setBounds(400,150,100,30);
			jbutton[0].addActionListener(this);
			jbutton[0].setForeground(Color.green);
			container.add(jbutton[0]);
			jtext[0]=new JTextArea("���߳�ִ����ʾ");
			jtext[0].setBounds(350,300,200,50);
			jtext[0].setBackground(Color.green);
			jtext[0].setEditable(false);
			container.add(jtext[0]);
			jtext[1]=new JTextArea("���߳�ִ����ʾ");
			jtext[1].setBounds(50,300,200,50);
			jtext[1].setBackground(Color.yellow);
			jtext[1].setEditable(false);
			container.add(jtext[1]);
			setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e){
			//���߳�ִ��
			if(e.getActionCommand()==jbutton[1].getText())
			{
				jtext[1].setText("���߳̿�ʼִ��.....");
				java.util.Date date2= new java.util.Date();
				Document document;
				try {
					document = Jsoup.connect("http://staff.whu.edu.cn/").get();//��ȡ��վ��ҳ
					final String phoneFom="(\\d{3}-\\d{8})|(\\d{11})|(\\d{3}-\\d{8}-\\d{4})";//�������ʽ
					final String emailFom="\\w*(\\.\\w*)*@\\w*(\\.\\w*)*";//�������ʽ
					final Pattern pattern1=Pattern.compile(phoneFom);
					final Pattern pattern2=Pattern.compile(emailFom);//pattern matcher������ȡ�绰�����ʼ�
					int i=0;//i������ȡ��ʦ������
					for(i=0;;i++)
					{
						try {
							document.getElementsByAttributeValue("class","details col-md-8 col-sm-8 col-xs-6").get(i);
						} catch (Exception e1) {
							break;// TODO: handle exception
						}
						
					}
					Thread pocess[]=new Thread[i];//���߳�
					for(int j=0;j<i;j++)
					{
						//��ȡÿ����ʦ��ҳ��url
						final String urlString="http://staff.whu.edu.cn/"+document.getElementsByAttributeValue("class","details col-md-8 col-sm-8 col-xs-6").get(j).select("a").attr("href");// TODO Auto-generated method stub
						pocess[j]=new Thread(new Runnable() {//�ڲ���
							
							@Override
							public void run() {
								Document document1=null;
								try {
									document1=Jsoup.connect(urlString).get();//��ȡÿ����ʦ����ҳ
								} catch (IOException e) {
									e.printStackTrace();
								}
								String name=null,tel=null,email=null,dire=null,process=null;//�ֱ�洢��ʦ��������ʦ�绰�������ʼ����о����򣬽�ʦ���
								//��ȡ������ʦ�����绰��������ʼ��о�������ַ���
								String general=document1.getElementsByAttributeValue("class", "details col-md-10 col-sm-9 col-xs-7").get(0).text();
								Matcher emailMatcher=pattern2.matcher(general);
								//�����������ʽ��ȡ�����ʼ�
								if(emailMatcher.find())
								{
									email=emailMatcher.group();
									while(emailMatcher.find())
										email=email+";"+emailMatcher.group();
								}	
								else {
									email="null";
								}
								//�����������ʽ��ȡ�绰����
								Matcher telmMatcher=pattern1.matcher(general);
								if(telmMatcher.find())
								{
									tel=telmMatcher.group();
									while(telmMatcher.find())
										tel=tel+";"+telmMatcher.group();
								}	
								else {
									tel="null";
								}
								//��ȡ��ʦ����
								if(!general.split(" ")[0].trim().equals(","))
									name=general.split(" ")[0];
								else {
									name="null";
								}
								//��ȡ��ʦ�о�����
								for(int k=0;k<general.split(" ").length;k++)
								{
									if(general.split(" ")[k].equals("�о�����"))
									{
										int m=k;
										String string="";
										while(true)
										{
											
											if(general.split(" ")[m+1].equals("��ϵ�绰��"))
											{
												if(string.isEmpty())
													dire="null";
												break;
											}
											else {
												string=string+general.split(" ")[m+1];
											}
											m++;
										}
										if(!string.isEmpty())
										{
											dire=string;
										}
										
									}	
								}
								Connection connection=null;
								Statement statement=null;
								//��ȡ��ʦ���
								if(!document1.getElementsByAttributeValue("class", "details col-md-12 col-sm-12 col-xs-12").get(0).text().isEmpty())
									process=document1.getElementsByAttributeValue("class", "details col-md-12 col-sm-12 col-xs-12").get(0).text();
								else {
									process="null";
								}
								try {
									//����ȡ����д�����ݿ�
									Class.forName("com.mysql.jdbc.Driver"); 
									connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/teacherinfo?useUnicode=true&characterEncoding=gb2312","root","root");
									statement=(Statement) connection.createStatement();
									statement.execute("INSERT INTO teacherinfomation1(��ʦ����,�о�����,�绰����,�����ʼ�,��ʦ���)VALUES('"+name+"','"+dire+"','"+tel+"','"+email+"','"+process+"')");
									statement.close();
									connection.close();
								} catch (Exception e) {
									// TODO: handle exception
								}
								
							}
						});
						pocess[j].start();//�߳̿�ʼִ��
					}
					java.util.Date date21= new java.util.Date();
					jtext[1].append("\n���̺߳�ʱԼ"+(date21.getTime()-date2.getTime())+"����");
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
			}
			if(e.getActionCommand()==jbutton[0].getText())
			{
				//���߳�����̷߳�����ͬС�����Բ���ע����
				jtext[0].setText("��ȡ���ϴ������ĵȴ�......\n");
				jbutton[0].setEnabled(false);
				java.util.Date date1= new java.util.Date();
				Document document=null;
				try {
					document=Jsoup.connect("http://staff.whu.edu.cn/").get();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				Document document1=null;
				Statement statement=null;
				Connection connection=null;
				Vector<Element> urlElements=new Vector<Element>();
				Vector<String> urlStrings=new Vector<String>();
				Vector<String> nameStrings=new Vector<String>();
				Vector<String> telStrings=new Vector<String>();
				Vector<String> emailStrings=new Vector<String>();
				Vector<String> proStrings=new Vector<String>();
				Vector<String> direStrings=new Vector<String>();
				String phoneFom="(\\d{3}-\\d{8})|(\\d{11})|(\\d{3}-\\d{8}-\\d{4})";
				String emailFom="\\w*(\\.\\w*)*@\\w*(\\.\\w*)*";
				Pattern pattern1=Pattern.compile(phoneFom);
				Pattern pattern2=Pattern.compile(emailFom);
				Matcher matcher1=null;
				Matcher matcher2=null;
				String general=null;
				for(int i=0;;i++)
				{
					try {
						urlElements.add( document.getElementsByAttributeValue("class","details col-md-8 col-sm-8 col-xs-6").get(i));
					} catch (Exception e1) {
						break;
					}	
				}
				for(int i=0;i<urlElements.size();i++)
				{
					urlStrings.add("http://staff.whu.edu.cn/"+urlElements.get(i).select("a").attr("href"));
				}
				for(int i=0;i<urlElements.size();i++)
				{	
					try {
						document1=Jsoup.connect(urlStrings.get(i)).get();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					general=document1.getElementsByAttributeValue("class", "details col-md-10 col-sm-9 col-xs-7").get(0).text();
					matcher1=pattern1.matcher(general);
					matcher2=pattern2.matcher(general);
					String s1="";
					if(matcher1.find()){
						s1=s1+matcher1.group();
						while (matcher1.find()) {
							s1=s1+";"+matcher1.group();
						}
						telStrings.add(s1);
					}
					else {
						telStrings.add("null");
					}
					s1="";
					if(matcher2.find()){
						s1=s1+matcher2.group();
						while (matcher2.find()) {
							s1=s1+";"+matcher2.group();
						}
						emailStrings.add(s1);
					}
					else {
						emailStrings.add("null");//
						
					}
					if(!general.split(" ")[0].trim().equals(","))
						nameStrings.add(general.split(" ")[0]);//
					else {
						nameStrings.add("null");
					}
					for(int j=0;j<general.split(" ").length;j++)
					{
						if(general.split(" ")[j].equals("�о�����"))
						{
							int m=j;
							String string="";
							while(true)
							{
								
								if(general.split(" ")[m+1].equals("��ϵ�绰��"))
								{
									if(string.isEmpty())
										direStrings.add("null");
									break;
								}
								else {
									string=string+general.split(" ")[m+1];
								}
								m++;
							}
							if(!string.isEmpty())
							{
								direStrings.add(string);
							}
							
						}
							
							
					}//
					if(!document1.getElementsByAttributeValue("class", "details col-md-12 col-sm-12 col-xs-12").get(0).text().isEmpty())
						proStrings.add(document1.getElementsByAttributeValue("class", "details col-md-12 col-sm-12 col-xs-12").get(0).text());
					else {
						proStrings.add("null");
					}
					jtext[0].setText("�Ѿ������"+(i+1)+"����Լ100��");//
				}
				try {
					Class.forName("com.mysql.jdbc.Driver");
				
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				try {
					connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/teacherinfo?useUnicode=true&characterEncoding=gb2312","root","root");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					statement=(Statement) connection.createStatement();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				for(int i=0;i<nameStrings.size();i++)
				{
					try {
						statement.execute("INSERT INTO teacherinfomation(��ʦ����,�о�����,�绰����,�����ʼ�,��ʦ���)VALUES('"+nameStrings.get(i)+"','"+direStrings.get(i)+"','"+telStrings.get(i)+"','"+emailStrings.get(i)+"','"+proStrings.get(i)+"')");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				try {
					statement.close();
					connection.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				java.util.Date date2= new java.util.Date();
				jtext[0].append("\n���̺߳�ʱ"+(date2.getTime()-date1.getTime())+"����");
				jbutton[0].setEnabled(true);
				
			}
			
		}

}
