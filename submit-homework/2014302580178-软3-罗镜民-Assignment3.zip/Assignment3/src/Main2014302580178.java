
import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.parser.*;
import org.jsoup.select.*;
import com.github.kevinsawicki.http.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

/*
 * 2014302580178 @author ��
 */

class paqu2014302580178 implements Runnable {
	private String name;
	private static int i = 0;// use to count which teacher has been get
	private static long time = 0;
	private static String urls[];

	public static void settime() {
		time = System.currentTimeMillis();
	}

	paqu2014302580178(String name, String urls[]) {
		this.name = name;
		this.urls = urls;
	}

	synchronized public int getindex() {
		i++;
		return i - 1;
	}

	synchronized public int geti() {
		return i;
	}

	@Override
	public void run() {
		int urlindex = 0;
		String mysqlurl = "jdbc:mysql://localhost:3306/java?characterEncoding=utf8";
		String username = "root";
		String password = "password";
		java.sql.Connection con = null;
		try {
			con = DriverManager.getConnection(mysqlurl, username, password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for (; geti() < urls.length;) {
			urlindex = getindex();
			// 同步获取url后可以非同步爬去页面
			String url = "http://www.ss.pku.edu.cn" + urls[urlindex];
			HttpRequest get;
			get = HttpRequest.get(url);
			String teacher = url.substring(64, url.length());// get teacher name
			File output = new File(teacher + ".html");
			get.receive(output);
			String phone = "";
			String email = "";
			String majar = "";
			String profile = "";

			Document html;
			try {
				html = Jsoup.parse(output, "UTF-8");
				Elements ul_lis = html.getElementsByClass("mainbody").first().getElementsByTag("ul").first()
						.getElementsByTag("li");
				// 提取email
				for (Element li : ul_lis) {
					if (li.hasClass("p_font_small")) {
						if (li.getElementsByTag("script").toString().length() > 49) {
							String temp = urlindex + " "
									+ li.getElementsByTag("script").first().toString().substring(123);
							Pattern unicodergx = Pattern.compile("'.*'");
							Matcher matcher = unicodergx.matcher(temp);
							if (matcher.find()) {
								String ext = matcher.group(0);
								Pattern regExp = Pattern.compile("&#\\d*;");
								Matcher matcher2 = regExp.matcher(ext);
								while (matcher2.find()) {
									String s = matcher2.group();
									String c = String.valueOf((char) Integer.parseInt(s.substring(2, s.length() - 1)));
									ext = ext.replace(s, c);
								}
								temp = ext.split("\\+")[0];
								email = temp.substring(1, temp.length() - 2) + "@ss.pku.edu.cn";
							}
						}
					}
					
				}
				String ext = ul_lis.toString();
				// 提取电话
				Pattern phonergx = Pattern.compile("\u7535\u8bdd.*<");
				Matcher matcher = phonergx.matcher(ext);
				while (matcher.find())
					phone = matcher.group().substring(3, matcher.group().length() - 1);

				// 提取领域
				Pattern majarrgx = Pattern.compile(">.*\u9886\u57df");
				Matcher matcher2 = majarrgx.matcher(ext);
				while (matcher2.find())
					majar = matcher2.group().substring(1);

				// 提取简介
				Element jianjie = html.getElementsByClass("a_wrapper").first();
				if (jianjie.getElementsByTag("p").hasClass("p_font_big"))
					profile = jianjie.getElementsByTag("p").text();

			} catch (IOException e) {
				// TODO Auto-generated catch block

				e.printStackTrace();
			}
			// 正则表达式email两个
			Pattern emailreg1 = Pattern.compile("");
			Pattern emailreg2 = Pattern.compile("");
			// 正侧表达式电话
			Pattern phonereg = Pattern.compile("");
			// 领域正侧表达式
			Pattern majorreg = Pattern.compile("");

			// System.out.print(name + " " + url + "\n");
			// 插入mysql
			try {
				// 加载MySql的驱动类
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				System.out.println("找不到驱动程序类 ，加载驱动失败！");
				e.printStackTrace();
			}
			
			PreparedStatement sttm;
			try {
				sttm = (PreparedStatement)con.prepareStatement("INSERT INTO java (name,majar,profile,phone,email) VALUES (?,?,?,?,?)");
				sttm.setString(1, teacher);
				sttm.setString(2, majar);
				sttm.setString(3, profile);
				sttm.setString(4, phone);
				sttm.setString(5, email);
				sttm.executeUpdate();
				sttm.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.print(name + " time:" + (System.currentTimeMillis() - time) + "\n");
		}
		 try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
public class Main2014302580178 {
	public static String[] geturls() {
		String urls[] = new String[50];
		/*
		 * pecking university urls http://www.ss.pku.edu.cn 缺这部分
		 * 需要补上再进行多线程or单线程爬取
		 */
		String url = "http://www.ss.pku.edu.cn/index.php/teacherteam/teacherlist";// 原始pecking教师列表，需要先处理下来url列表
		HttpRequest get;
		get = HttpRequest.get(url);
		File output = new File("out.html");
		get.receive(output);
		try {
			Document html = Jsoup.parse(output, "UTF-8");
			Elements liebiao = html.getElementById("content").getElementsByClass("ss-general-info").first()
					.getElementsByTag("a");
			int count = 0;
			for (Element one : liebiao) {

				urls[count] = one.attr("href");
				// System.out.println(urls[count]);
				count++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return urls;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("正在获取url列表，稍后开始爬取");
		String[] urls = geturls();
		Scanner in = new Scanner(System.in);
		int ThreadSetting = 0;
		System.out.println("one Thread please enter 1,other int will be def to two thread:");
		ThreadSetting = in.nextInt();
		// System.out.print(ThreadSetting);

		if (ThreadSetting == 1) {
			paqu2014302580178.settime();
			paqu2014302580178 paquone = new paqu2014302580178("A", urls);
			Thread paqu1 = new Thread(paquone);
			paqu1.start();
		} else {
			paqu2014302580178.settime();
			paqu2014302580178 paquone = new paqu2014302580178("A", urls);
			paqu2014302580178 paqutwo = new paqu2014302580178("B", urls);
			paqu2014302580178 paqut = new paqu2014302580178("C", urls);
			Thread paqu1 = new Thread(paquone);
			Thread paqu2 = new Thread(paqutwo);
			Thread paqu3 = new Thread(paqut);
			paqu1.start();
			paqu2.start();
			paqu3.start();

		}

	}

}
