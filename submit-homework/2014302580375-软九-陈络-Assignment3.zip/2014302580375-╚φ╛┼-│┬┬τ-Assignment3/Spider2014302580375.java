import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Spider2014302580375 {
	public static String[] name;
	public static String[] department;
	public static String[] title;
	public static String url;


	public Spider2014302580375(){
		name=new String[7];
		department=new String[7];
		title=new String[7];
		url="http://www.wpi.edu/academics/index.html";
	}
	public static void getInformation()throws IOException{
		Document doc = Jsoup.connect(url).get();			
		Elements elements=doc.select(".faculty");
		
		int i=0;
		for(Element element:elements){
			String spl1=element.text();
			String[] str=spl1.split("Department:");
			String[] str2=str[0].split("Name:");
			String[] str3=str[1].split("Title:");
			
			name[i]=str2[1];
			department[i]=str3[0];
			title[i]=str3[1];
//			System.out.println(name[i]);
//			System.out.println(department[i]);
//			System.out.println(title[i]);
			i++;
	}
		

}
}
