import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main2014302580375 {

	public static void main(String[] args) throws InterruptedException{
		// TODO �Զ����ɵķ������
		
		Spider2014302580375 spider=new Spider2014302580375();
		
		SpiderThread2014302580375 thread1 = new SpiderThread2014302580375();  
		SpiderThread2014302580375 thread2 = new SpiderThread2014302580375(); 
		SpiderThread2014302580375 thread3 = new SpiderThread2014302580375();
		
		thread1.start();
		thread2.start();
		System.out.println("˫�߳���ʱ�� "+Long.toString(thread1.time+thread2.time));
		try {
			mySQL2014302580375.setInSQL();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
		
		
		
		
		
		thread3.start(); 
		
		try {
			mySQL2014302580375.setInSQL();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		System.out.println("���߳���ʱ�� "+Long.toString(thread3.time));

	}
	}

