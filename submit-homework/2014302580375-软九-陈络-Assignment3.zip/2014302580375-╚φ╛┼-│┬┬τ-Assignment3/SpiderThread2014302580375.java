import java.io.IOException;
import java.sql.SQLException;


public class SpiderThread2014302580375 extends Thread{
	long time;
	public void run(){  
		long start = System.currentTimeMillis();	
		try {
			Spider2014302580375.getInformation();
			
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		//System.out.println("�߳�����ʱ����"+(System.currentTimeMillis() - start));
		time=System.currentTimeMillis() - start;
    }  

}
