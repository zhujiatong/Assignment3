package net.zghen;
import static net.zghen.Main2014302580374.*;

public class SyncScreen2014302580374 extends Thread {

	public void run(){
		output = screen.getText();
		while(true){
			if(!output.equals(screen.getText())){
				screen.setText(output);
			}
		}
	}
}
