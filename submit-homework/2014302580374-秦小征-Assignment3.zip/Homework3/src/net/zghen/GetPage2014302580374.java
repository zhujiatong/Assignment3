package net.zghen;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;

public class GetPage2014302580374 {
	public String url = "";
	public String name = "";
	public String tel = "";
	public String email = "";
	public String content = "";
	public static int index = 0;
	
	public void init(String iurl) throws IOException{
		index++;
		url= iurl;
		 String fName = "./" + index + ".html";
		 HttpRequest response = HttpRequest.get(url);
		 response.receive(new File(fName));
		 String inFile = file2String(new File("./" + index + ".html"));
		 Document doc = Jsoup.parse(inFile);
		 Elements els = doc.getElementsByClass("about_info");
		 
		 for(Element tmp : els){
			 Elements elements = tmp.getElementsByTag("li");
			 
			 name = elements.get(0).html();
			 tel = elements.get(5).html();
			 email = elements.get(7).html();
		 }
		 els = doc.getElementsByClass("info_list_ct");
		 if(els.isEmpty()){
			 content = "";
		 }else{
			 els = els.get(0).getElementsByTag("font");
			 if(els.isEmpty())
				 content = "";
			 else
				 content = els.get(0).html();
		 }
		 //System.out.println(name + "\n" + tel + "\n" + email + "\n" + content);
	}
	public int saveToMysql() throws SQLException{
		 String sql;
		 String url = "jdbc:mysql://127.0.0.1:3306/testa?"  
	                + "user=root&"
	                + "password=new_passwd&"
	                + "useUnicode=true&"
	                + "characterEncoding=UTF8";
		 Connection conn = null;
		 try{
			 Class.forName("com.mysql.jdbc.Driver");
			 conn = DriverManager.getConnection(url);
			 Statement stmt = conn.createStatement();
			 if(name.length() > 100){
				 name = name.substring(0, 99);
			 }
			 if(tel.length() > 100){
				 tel  = tel.substring(0, 99);
			 }
			 if(email.length() > 100){
				 email = email.substring(0, 99);
			 }
			 if(content.length()> 20000){
				 content = content.substring(0, 19999);
			 }
	         sql = "insert into infoss(name,tel,email,content) values('" + name +"','"+ tel +"','"+ email +"','"+ content +"')";
	         stmt.executeUpdate(sql);
		 	}catch (SQLException e) {
	            System.out.println("----- mysql error ----");
	            e.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            conn.close();
	        }
		
		return 0;
	}
	public static String file2String(File file) throws IOException{
		InputStream is = new FileInputStream(file);
		BufferedReader in = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		StringBuffer buffer = new StringBuffer();
		String line = "";
		while((line = in.readLine()) != null){
			buffer.append(line);
		}
		in.close();
		return buffer.toString();
	}
}
