package net.zghen;

import java.io.IOException;
import java.sql.SQLException;

public class PaThread2014302580374 extends Thread {
	public String url;
	public static int index = 0;
	public  int myIndex = 0;
	public void run(){
		index++;
		myIndex = index;
		System.out.println("thread " + myIndex + " begin");
		GetPage2014302580374 gp = new GetPage2014302580374();
		try {
			gp.init(url);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			gp.saveToMysql();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Main2014302580374.screencontent += "+";
		System.out.println("thread " + myIndex + " end");
		Main2014302580374.finish++;
        return ;
	}
}
