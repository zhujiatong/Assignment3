package net.zghen;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;

public class Main2014302580374 {
	public static int finish = 0;
	public static JTextArea screen = new JTextArea("welcome");
	public static JButton btn;
	public static JButton btnc;
	public static String output ="";
	private static JFrame frame;
	private static JButton btna;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		frame = new JFrame("welcome");
		btn = new JButton("单线程");
		btna = new JButton("多线程");
		btnc = new JButton("测试时使用");
		btna.setBackground(Color.green);

		frame.setLayout(new GridLayout(5,2,100,20));
	//	frame.add(label);
		screen.setText("welcome---");
		screen.setSize(frame.getWidth(), 100);
		frame.add(screen);
		SyncScreen2014302580374 th = new SyncScreen2014302580374();
		th.start();
		btna.addActionListener(new ActionListener(){
	    	   public void actionPerformed(ActionEvent e){
	    		   try {
					btnaAction();
				} catch (IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	    	   }
	       });
		btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				try {
					btnAction();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnc.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				try {
					btncAction();
				} catch (IOException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		frame.add(btn);
		frame.add(btna);
		frame.add(btnc);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setLocation(500, 200);
	}
	public static String baseurl= "http://cs.whu.edu.cn/plus/";
	public static String screencontent = "";
	public static void btnAction() throws IOException, SQLException{
		int i = 0;
		Set<String> urls = getAllUrls(baseurl);
		GetPage2014302580374 gp = new GetPage2014302580374();
		long timea =  System.currentTimeMillis();
		for(String url : urls){
			i++;
			//screen.setText(String.valueOf(i));
			//output = String.valueOf(i);
			System.out.println(i);
			gp.init(baseurl + url);
			gp.saveToMysql();
		}
		long timeb = System.currentTimeMillis() - timea;
		output = "20个网页：单线程耗时： " + timeb + "毫秒";
		screen.setText("finished");
		System.out.println("using: " + timeb);
	}
	public static void btnaAction() throws IOException, SQLException{
		Set<String> urls= getAllUrls(baseurl);
		long timea =  System.currentTimeMillis();
		PaThread2014302580374 pt= null;
		for(String url: urls){
			pt = new PaThread2014302580374();
			pt.url = baseurl + url;
			pt.start();
		}
		while(finish < 20){
			System.out.println("finish " + finish);
		}
		long timeb = System.currentTimeMillis() - timea;
		System.out.println("using: " + timeb + " 毫秒");
		output = "20个网页：多线程耗时：" + timeb + " 毫秒";
	}
	public static void btncAction() throws IOException, SQLException{
		//GetPage gp = new GetPage();
		//gp.init("http://cs.whu.edu.cn/plus/view.php?aid=1626");
		//gp.saveToMysql();
		System.out.println(System.currentTimeMillis());
	}
	public static Set<String> getAllUrls(String baseurl) throws IOException{
		Set<String> urls = new  HashSet<String>();
		String fName = "./" + "main" + ".html";
		String iurl = baseurl + "list.php?tid=36";
		 HttpRequest response = HttpRequest.get(iurl);
		 response.receive(new File(fName));
		 String inFile = GetPage2014302580374.file2String(new File("./" + "main" + ".html"));
		 Document doc = Jsoup.parse(inFile);
		 Elements els = doc.getElementsByTag("a");
		 for(int i = 280; i < 300; i++){  // 280-480
			 urls.add(els.get(i).attr("href"));
		 }
		 
		return urls;
	}
}


