/**
 * Created by terry on 15-11-3.
 */
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Contraller2014302580282
{
    // 数据库操作对象
    private static Model2014302580282 conn = new Model2014302580282();

    private enum INDEX
    {
        NAME, EMAIL, PHONE,
        MAJOR, INTRODUCTION, PERSONAL_URL
    }

    private Document getDocument(String url) throws IOException
    {
        return Jsoup.connect(url).get();
    }

    // 正则有毒,jsoup也有毒!!!
    private String[] getEmailAndPhoneAndIntroduction(String personalUrl)
    {
        String[] result = new String[3];

        result[0] = " ";
        result[1] = " ";
        result[2] = " ";

        // 这两个老师的页面进不去！！！！！我说怎么一直报错！！！！！！！
        if (personalUrl.equals("http://cs.whu.edu.cn/plus/view.php?aid=1661") || personalUrl.equals("http://cs.whu.edu.cn/plus/view.php?aid=1704"))
        {
            return result;
        }

        Document personalPage = null;

        try
        {
            personalPage = getDocument(personalUrl);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        Element containerDiv = personalPage.getElementById("container");

        String phoneLi = containerDiv.select("ul").get(2).select("li").get(5).text();
        result[1] = phoneLi.length() <= 7 ? " " : phoneLi.substring(7, phoneLi.length());
        String emailLi = containerDiv.select("ul").get(2).select("li").get(7).text();
        result[0] = emailLi.length() <= 3 ? " ": emailLi.substring(3, emailLi.length());

        if (personalPage.select("div.info_list").select("p").text().equals(""))
        {
            return result;
        }

        String introduction = personalPage.select("div.info_list").select("p").first().text();
        result[2] = introduction;

        return result;
    }

    // 返回第一页的解析结果
    private List<String[]> parseFirstPage() throws IOException
    {
        String preUrl = "http://cs.whu.edu.cn/plus/";
        String firstPageUrl = "http://cs.whu.edu.cn/plus/list.php?tid=36";

        // 要解析的文档
        Document firstPage = getDocument(firstPageUrl);

        // 要返回的解析结果
        List<String[]> rows = new ArrayList<>();

        Elements dds = firstPage.select("dd.j_name");
        for (Element dd : dds)
        {
            // 获取不到名字的跳过
            if (dd.select("a").text().equals(""))
            {
                continue;
            }

            String[] row = new String[6];

            row[INDEX.NAME.ordinal()] = dd.select("a").text();  // 姓名
            row[INDEX.PERSONAL_URL.ordinal()] = preUrl + dd.select("a").attr("href");    // 个人主页URL
            row[INDEX.MAJOR.ordinal()] = dd.select("span.job_research").text(); // 研究方向

            rows.add(row);
        }

        return rows;
    }

    // 多线程解析
    private class multiThreadParse extends Thread
    {
        public multiThreadParse(List<String[]> rows)
        {
            this.rows = rows;
        }

        public void run()
        {
            for (int i = 0; i != rows.size(); i++)
            {
                String[] row = rows.get(i);
                String personalUrl = row[INDEX.PERSONAL_URL.ordinal()];

                String[] temp;   // 依次获取所有教师的个人信息

                temp = getEmailAndPhoneAndIntroduction(personalUrl);

                row[INDEX.EMAIL.ordinal()] = temp[0].equals("") ? " " : temp[0].replace("\"", "");
                row[INDEX.PHONE.ordinal()] = temp[1].equals("") ? " " : temp[1].replace("\"", "");
                row[INDEX.INTRODUCTION.ordinal()] = temp[2].equals("") ? " " : temp[2].replace("\"", "");

                // 插入到数据库
                conn.insert(row[0], row[1], row[2], row[3], row[4]);
            }
        }

        private List<String[]> rows;
    }

    public int singleThread() throws IOException
    {
        List<String[]> rows = parseFirstPage();

        // 获取教师个人信息
        for (int i = 0; i != rows.size(); i++)
        {
            String[] row = rows.get(i);

            String personalUrl = row[INDEX.PERSONAL_URL.ordinal()];

            String[] temp = getEmailAndPhoneAndIntroduction(personalUrl);   // 依次获取所有教师的个人信息

            row[INDEX.EMAIL.ordinal()] = temp[0].equals("") ? " " : temp[0].replace("\"", "");
            row[INDEX.PHONE.ordinal()] = temp[1].equals("") ? " " : temp[1].replace("\"", "");
            row[INDEX.INTRODUCTION.ordinal()] = temp[2].equals("") ? " " : temp[2].replace("\"", "");

            // 插入到数据库
            conn.insert(row[0], row[1], row[2], row[3], row[4]);
        }

        return rows.size();
    }

    public int multiThread() throws IOException, InterruptedException {
        List<String[]> rows = parseFirstPage();

        // 10个线程同时解析
        int threadNums = 10;
        int childListLen = rows.size() / threadNums;

        for (int i = 0; i != threadNums; i++)
        {
            List<String[]> childList = rows.subList(i * childListLen, childListLen * (i + 1));
            multiThreadParse m = new multiThreadParse(childList);
            m.start();
        }

        List<String[]> restList = rows.subList(childListLen * threadNums, rows.size());

        multiThreadParse l = new multiThreadParse(restList);
        l.start();
        l.join();

        return rows.size();

    }

}
