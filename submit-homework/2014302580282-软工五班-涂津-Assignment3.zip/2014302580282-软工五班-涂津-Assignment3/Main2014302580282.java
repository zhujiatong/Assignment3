/**
 * Created by terry on 15-11-3.
 */
import java.io.IOException;


public class Main2014302580282
{
    public static void main(String[] args) throws IOException, InterruptedException {
        Contraller2014302580282 c = new Contraller2014302580282();

        long startTime = System.currentTimeMillis();

        // 单线程
        int singleNums = c.singleThread();
        System.out.println("单线程运行时间： " + (System.currentTimeMillis() - startTime) + "ms\n有效记录条数： " + singleNums);

        // 多线程
        startTime = System.currentTimeMillis();
        int multiNums = c.multiThread();
        System.out.println("多线程运行时间： " + (System.currentTimeMillis() - startTime) + "ms\n有效记录条数： " + multiNums);
    }
}
