/**
 * Created by terry on 15-11-3.
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class Model2014302580282
{
    // 数据库名
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/assignment3?useUnicode=true&characterEncoding=utf-8";

    // 数据库用户名和密码
    private static final String USERNAME = "root";
    private static final String PASSWORD = "password";

    // 数据库连接
    private static Connection conn;

    // 初始化数据库连接
    Model2014302580282()
    {
        try
        {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        }
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
        }
    }

    // 查询
    public List query(String sql)
    {
        List<String[]> rows = new ArrayList<>();
        try
        {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData md = rs.getMetaData();
            int col = md.getColumnCount();

            while (rs.next())
            {
                String[] row = new String[col];
                for (int i = 1; i <= col; i++)
                {
                    row[i - 1] = rs.getString(i);
                }
                rows.add(row);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return rows;
    }

    // 插入
    private void insert_(String sql)
    {
        try
        {
            Statement st = conn.createStatement();
            st.executeUpdate(sql);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    // 插入教师信息
    public void insert(String name, String email, String phone, String major, String introduction)
    {
        String sql = "insert into teacher_info values(\"" + name + "\", " + "\"" + email + "\", " + "\"" + phone
        + "\", " + "\"" + major + "\", " + "\"" + introduction + "\")";
        insert_(sql);
    }

}
